package asd.itamio.createtnt;

import asd.itamio.ModInfoPrinter;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2396;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Create TNT — makes TNT explode like artillery shells: big smoke plumes,
 * blast rays, delayed boom sound, screen shake, energy-transfer block
 * destruction, and structural collapse.
 */
public class BetterTNTs implements ModInitializer {

    public static final String MOD_ID = "createtnt";
    public static final String MOD_NAME = "Create TNT";
    public static final String VERSION = "2.0.0";

    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final String CREDITS =
        "Particle system, smoke textures, blast-wave and screen-shake effects, and sound assets " +
        "are from the mod Create Big Cannons by rbasamoyai; its explosion physics were " +
        "referenced and adapted with our own tweaks. Structure collapse cascade scheduling " +
        "is adapted from the mod Simple Block Physics by FerrinEmber.";

    // ---- Registries (direct, Fabric style) ----
    public static class_3414 EXPLOSION_BOOM;

    public static class_1299<EntityEnhancedTNTPrimed> ENHANCED_TNT;
    public static class_1299<EntityEnhancedFallingBlock> ENHANCED_FALLING_BLOCK;

    public static class_2396<ShellSmokeOption> SHELL_EXPLOSION_SMOKE;
    public static class_2396<ShellCloudOption> SHELL_EXPLOSION_CLOUD;
    public static class_2396<BlastWaveOption> SHELL_BLAST_WAVE;

    @Override
    public void onInitialize() {
        EXPLOSION_BOOM = class_2378.method_10230(class_7923.field_41172,
            new class_2960(MOD_ID, "explosion_boom"),
            class_3414.method_47908(new class_2960(MOD_ID, "explosion_boom")));

        ENHANCED_TNT = class_2378.method_10230(class_7923.field_41177,
            new class_2960(MOD_ID, "enhanced_tnt_primed"),
            class_1299.class_1300.<EntityEnhancedTNTPrimed>method_5903(EntityEnhancedTNTPrimed::new, class_1311.field_17715)
                .method_17687(0.98F, 0.98F).method_27299(10).method_27300(10)
                .method_5905(new class_2960(MOD_ID, "enhanced_tnt_primed").toString()));
        ENHANCED_FALLING_BLOCK = class_2378.method_10230(class_7923.field_41177,
            new class_2960(MOD_ID, "enhanced_falling_block"),
            class_1299.class_1300.<EntityEnhancedFallingBlock>method_5903(EntityEnhancedFallingBlock::new, class_1311.field_17715)
                .method_17687(0.98F, 0.98F).method_27299(10).method_27300(20)
                .method_5905(new class_2960(MOD_ID, "enhanced_falling_block").toString()));

        SHELL_EXPLOSION_SMOKE = class_2378.method_10230(class_7923.field_41180,
            new class_2960(MOD_ID, "shell_explosion_smoke"), new ShellSmokeParticleType());
        SHELL_EXPLOSION_CLOUD = class_2378.method_10230(class_7923.field_41180,
            new class_2960(MOD_ID, "shell_explosion_cloud"), new ShellCloudParticleType());
        SHELL_BLAST_WAVE = class_2378.method_10230(class_7923.field_41180,
            new class_2960(MOD_ID, "shell_blast_wave"), new BlastWaveParticleType());

        // Plain .txt config with live reload, in the config dir.
        java.io.File cfgFile = net.fabricmc.loader.api.FabricLoader.getInstance()
            .getConfigDir().resolve("createtnt.txt").toFile();
        ModConfig.load(cfgFile);

        // Server-tick handler processing scheduled (one-by-one) chain
        // detonations.
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
            EntityEnhancedTNTPrimed.tickScheduled();
            RocketTracker.tickAll();
        });

        ModInfoPrinter.print(LOGGER::info, MOD_NAME, VERSION);
        LOGGER.info(CREDITS);
        LOGGER.info("{} initialized. Enhanced TNT explosion physics active.", MOD_NAME);
    }
}
