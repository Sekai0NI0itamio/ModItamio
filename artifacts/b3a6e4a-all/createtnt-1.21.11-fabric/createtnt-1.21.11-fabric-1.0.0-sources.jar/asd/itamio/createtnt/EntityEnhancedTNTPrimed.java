package asd.itamio.createtnt;

import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1541;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3486;

/**
 * Enhanced primed TNT with water-aware fuse behavior.
 *
 * <p>Water interaction rules:</p>
 * <ul>
 *   <li>If the TNT is in water and has been lit for less than 1 second
 *       (20 ticks), it unlights after 0.5 seconds (10 ticks) and reverts
 *       to a placed TNT block.</li>
 *   <li>If the TNT has been lit for 1+ second (20+ ticks) before entering
 *       water, it stays lit and explodes normally — the explosion still
 *       destroys blocks and scatters fluids as if it exploded on land.</li>
 *   <li>If the fuse is about to expire (fuse ≤ 1), the water-unlit check
 *       is skipped so chain-reaction TNT always detonates.</li>
 * </ul>
 *
 * <p>The explosion itself is handled by {@link EnhancedExplosion}, created
 * directly at fuse end (reliable in water).</p>
 */
public class EntityEnhancedTNTPrimed extends class_1541 {

    /** Ticks since the TNT was ignited. Used to determine water-unlit behavior. */
    private int ticksSinceLit;

    public EntityEnhancedTNTPrimed(net.minecraft.class_1299<? extends class_1541> type,
                                   class_1937 level) {
        super(type, level);
        this.ticksSinceLit = 0;
    }

    public EntityEnhancedTNTPrimed(class_1937 level, double x, double y, double z, class_1309 igniter) {
        this(BetterTNTs.ENHANCED_TNT, level);
        this.method_5814(x, y, z);
        double d0 = level.field_9229.method_43058() * (Math.PI * 2.0D);
        this.method_18800(-Math.sin(d0) * 0.02D, 0.2D, -Math.cos(d0) * 0.02D);
        this.method_6967(80);
        this.field_6014 = x;
        this.field_6036 = y;
        this.field_5969 = z;
        this.ticksSinceLit = 0;
    }

    @Override
    public void method_5773() {
        this.field_6014 = this.method_23317();
        this.field_6036 = this.method_23318();
        this.field_5969 = this.method_23321();

        // Physics — same as vanilla PrimedTnt.
        if (!this.method_5740()) {
            this.method_18799(this.method_18798().method_1031(0.0D, -0.04D, 0.0D));
        }
        this.method_5784(class_1313.field_6308, this.method_18798());
        this.method_18799(this.method_18798().method_1021(0.98D));
        if (this.method_24828()) {
            this.method_18799(this.method_18798().method_18805(0.7D, -0.5D, 0.7D));
        }

        boolean inWater = this.method_5799();
        this.ticksSinceLit++;

        // --- Water unlit logic ---
        // If in water, lit for 0.5-1 seconds (10-19 ticks), and the fuse
        // isn't about to expire, unlit and revert to a TNT block.
        // If lit for 1+ second (20+ ticks), water doesn't affect it —
        // the TNT explodes normally and the EnhancedExplosion scatters
        // water/lava as falling fluid entities.
        // Server-only: the server decides when to unlit; the client just
        // renders until the server kills the entity.
        int currentFuse = this.method_6969();
        if (!this.method_73183().method_8608() && inWater && this.ticksSinceLit >= ModConfig.waterUnlightMinTicks
            && this.ticksSinceLit < ModConfig.waterUnlightMaxTicks && currentFuse > 1) {
            this.unlit();
            return;
        }

        // Normal fuse countdown.
        int newFuse = currentFuse - 1;
        this.method_6967(newFuse);

        if (newFuse <= 0) {
            // Explode BEFORE discard() so chain-reaction logic can still
            // find this TNT entity via getEntitiesOfClass.
            if (!this.method_73183().method_8608()) {
                // Directly create an EnhancedExplosion — reliable in water.
                // 1.0x to 3.0x random power multiplier — each TNT varies in strength.
                float powerMult = 1.0F + this.method_73183().method_8409().method_43057() * 2.0F;
                float blockPower = ModConfig.blockPower * powerMult;
                float entityPower = ModConfig.entityPower * powerMult;
                // Particle power is decoupled from destruction power (the
                // smoke stays BIG even though destruction is scaled down):
                // based on full tntStrength with a gentle multiplier curve.
                float particlePower = ModConfig.tntStrength * (1.0F + (powerMult - 1.0F) * 0.25F);

                // --- Fluid resistance scaling ---
                // Explosions in water have more resistance (reduced power).
                // Explosions in lava have even more resistance and decreased
                // strength. The TNT still destroys blocks and scatters fluids,
                // but with reduced reach.
                class_2338 tntPos = this.method_24515();
                boolean inWaterBlock = this.method_73183().method_8316(tntPos).method_15767(class_3486.field_15517);
                boolean inLavaBlock = this.method_73183().method_8316(tntPos).method_15767(class_3486.field_15518);
                if (inWaterBlock) {
                    blockPower *= ModConfig.waterResistanceScale;
                    entityPower *= ModConfig.waterResistanceScale;
                }
                if (inLavaBlock) {
                    blockPower *= ModConfig.lavaResistanceScale;
                    entityPower *= ModConfig.lavaResistanceScale;
                }

                EnhancedExplosion explosion = new EnhancedExplosion(
                    this.method_73183(), this,
                    this.method_23317(), this.method_23318() + (double) (this.method_17682() / 16.0F), this.method_23321(),
                    blockPower, entityPower, false, true, particlePower);
                explosion.detonate();
                explosion.finalizeExplosion(true);

                // --- Simultaneous chain detonation ---
                // All TNT blocks and primed TNT entities caught in the blast
                // are collected and detonated IMMEDIATELY (same tick), so the
                // entire field goes up at once instead of one-by-one.
                detonateChain(explosion, blockPower, entityPower);
                chainVisited.clear();
            }
            this.method_31472();
        } else if (this.method_73183().method_8608()) {
            this.method_73183().method_8406(net.minecraft.class_2398.field_11251,
                this.method_23317(), this.method_23318() + 0.5D, this.method_23321(), 0.0D, 0.0D, 0.0D);
        }
    }

    /**
     * Unlights the TNT: kills the entity and places a TNT block (or drops an
     * item if the position is occupied). Plays a fire-extinguish sound to
     * signal the dousing.
     */
    private void unlit() {
        this.method_31472();
        if (!this.method_73183().method_8608()) {
            class_2338 pos = this.method_24515();
            if (this.method_73183().method_8320(pos).method_45474()) {
                this.method_73183().method_8652(pos, class_2246.field_10375.method_9564(), 3);
            } else {
                // 1.21.11: spawnAtLocation takes the ServerLevel explicitly.
                this.method_5775((net.minecraft.class_3218) this.method_73183(),
                    new class_1799(class_2246.field_10375));
            }
            this.method_73183().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(),
                class_3417.field_15102, class_3419.field_15245, 0.8F, 1.2F);
        }
    }

    // 1.21.11: entity NBT goes through the ValueOutput/ValueInput abstraction.
    @Override
    protected void method_5652(net.minecraft.class_11372 tag) {
        super.method_5652(tag);
        tag.method_71465("TicksSinceLit", this.ticksSinceLit);
    }

    @Override
    protected void method_5749(net.minecraft.class_11368 tag) {
        super.method_5749(tag);
        this.ticksSinceLit = tag.method_71424("TicksSinceLit", 0);
    }

    /**
     * Recursively detonates all TNT blocks and primed TNT entities caught in
     * the blast, all in the same tick. Uses a visited set to prevent infinite
     * recursion when TNTs are packed tightly.
     */
    private static final java.util.Set<class_2338> chainVisited = new java.util.HashSet<>();

    /** A TNT position scheduled to explode at a later world tick. Used when the
     *  user disables simultaneous chain detonation in the config. */
    private static final java.util.List<ScheduledDetonation> scheduledDetonations =
        java.util.Collections.synchronizedList(new java.util.ArrayList<>());

    /**
     * Processes chain TNTs collected by an explosion. The center (cx/cy/cz) is
     * the position the blast originated from, used to find and scatter primed
     * TNT entities in range.
     */
    private void detonateChain(EnhancedExplosion explosion, float blockPower, float entityPower) {
        // The chain search is centered on THIS TNT's position.
        detonateChainAt(this.method_73183(), this.method_23317(), this.method_23318(), this.method_23321(), this,
            explosion, blockPower, entityPower);
    }

    /**
     * Position-based chain detonation. Finds primed TNT entities around the
     * given center and scatters them, then either detonates all collected TNT
     * block positions immediately (simultaneous mode) or schedules them with a
     * staggered delay (one-by-one mode).
     */
    private static void detonateChainAt(class_1937 level, double cx, double cy, double cz,
                                        EntityEnhancedTNTPrimed cause,
                                        EnhancedExplosion explosion,
                                        float blockPower, float entityPower) {
        java.util.List<class_2338> tntPositions = new java.util.ArrayList<>(
            explosion.getChainedTNTPositions());

        // Find primed TNT entities around the blast center and scatter them.
        float chainRadius = Math.max(blockPower, entityPower) * 2.0F + 4.0F;
        List<class_1541> chainedTNTs = level.method_18467(
            class_1541.class,
            new class_238(
                cx - chainRadius, cy - chainRadius, cz - chainRadius,
                cx + chainRadius, cy + chainRadius, cz + chainRadius));

        for (class_1541 tnt : chainedTNTs) {
            if (tnt == cause) continue;
            double dx = tnt.method_23317() - cx;
            double dy = tnt.method_23318() - cy;
            double dz = tnt.method_23321() - cz;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > 0.0D) {
                double scatter = 0.4D * (1.0D - dist / (double) chainRadius);
                scatter = Math.max(0.1D, scatter);
                tnt.method_18799(tnt.method_18798().method_1031(
                    (dx / dist) * scatter,
                    (dy / dist) * scatter + 0.2D,
                    (dz / dist) * scatter));
            }
        }

        if (ModConfig.simultaneousChainDetonation) {
            // Detonate all collected TNT positions immediately (same tick).
            for (class_2338 pos : tntPositions) {
                if (chainVisited.contains(pos)) continue;
                chainVisited.add(pos);
                detonatePosition(level, pos, cause);
            }
        } else {
            // One-by-one: schedule each position to explode with a staggered
            // delay so they go off sequentially rather than all at once.
            long now = level.method_75260();
            int index = 0;
            for (class_2338 pos : tntPositions) {
                if (chainVisited.contains(pos)) continue;
                chainVisited.add(pos);
                long fireAt = now + (long) ModConfig.chainDetonationDelay * (index + 1);
                scheduledDetonations.add(new ScheduledDetonation(
                    level, pos, cause, fireAt));
                index++;
            }
        }
    }

    /**
     * Detonates a single TNT block position immediately: applies fluid-
     * resistance scaling, creates the enhanced explosion, and recursively
     * processes any TNTs caught in this chain blast (respecting the
     * simultaneous/one-by-one config).
     */
    private static void detonatePosition(class_1937 level, class_2338 pos, EntityEnhancedTNTPrimed cause) {
        // Fluid resistance scaling for chain explosions.
        float powerMult = 1.0F + level.method_8409().method_43057() * 2.0F;
        float chainBlockPower = ModConfig.blockPower * powerMult;
        float chainEntityPower = ModConfig.entityPower * powerMult;
        float chainParticlePower = ModConfig.tntStrength * (1.0F + (powerMult - 1.0F) * 0.25F);
        boolean inWater = level.method_8316(pos).method_15767(class_3486.field_15517);
        boolean inLava = level.method_8316(pos).method_15767(class_3486.field_15518);
        if (inWater) {
            chainBlockPower *= ModConfig.waterResistanceScale;
            chainEntityPower *= ModConfig.waterResistanceScale;
        } else if (inLava) {
            chainBlockPower *= ModConfig.lavaResistanceScale;
            chainEntityPower *= ModConfig.lavaResistanceScale;
        }

        double cx = pos.method_10263() + 0.5D;
        double cy = pos.method_10264() + 0.5D;
        double cz = pos.method_10260() + 0.5D;
        // Particle power uses the same tntStrength-based sizing as primary
        // explosions so chain detonations produce equally big smoke clouds.
        EnhancedExplosion chainExplosion = new EnhancedExplosion(
            level, cause, cx, cy, cz,
            chainBlockPower, chainEntityPower, false, true, chainParticlePower);
        chainExplosion.detonate();
        chainExplosion.finalizeExplosion(true);

        // Recursively process any TNTs caught in this chain explosion,
        // centered on this position.
        detonateChainAt(level, cx, cy, cz, cause, chainExplosion, chainBlockPower, chainEntityPower);
    }

    /**
     * Processes scheduled (one-by-one) chain detonations on the server tick.
     * Any entry whose fire time has passed is detonated now and removed.
     * Registered on the Forge event bus in {@link BetterTNTs}.
     */
    /** Processes scheduled (one-by-one) chain detonations on the server
     *  tick. Called from the Fabric server-tick callback. */
    public static void tickScheduled() {
        if (scheduledDetonations.isEmpty()) return;

        // Snapshot the due entries while holding the lock briefly, then
        // process them outside the synchronized block to avoid reentrancy
        // (each detonation may add new scheduled entries).
        java.util.List<ScheduledDetonation> due = new java.util.ArrayList<>();
        synchronized (scheduledDetonations) {
            java.util.Iterator<ScheduledDetonation> iter = scheduledDetonations.iterator();
            while (iter.hasNext()) {
                ScheduledDetonation sd = iter.next();
                if (sd.level.method_75260() >= sd.fireAt) {
                    due.add(sd);
                    iter.remove();
                }
            }
        }
        for (ScheduledDetonation sd : due) {
            detonatePosition(sd.level, sd.pos, sd.cause);
        }
    }

    /** Holder for a deferred chain-detonation. */
    private static final class ScheduledDetonation {
        final class_1937 level;
        final class_2338 pos;
        final EntityEnhancedTNTPrimed cause;
        final long fireAt;

        ScheduledDetonation(class_1937 level, class_2338 pos, EntityEnhancedTNTPrimed cause, long fireAt) {
            this.level = level;
            this.pos = pos;
            this.cause = cause;
            this.fireAt = fireAt;
        }
    }
}
