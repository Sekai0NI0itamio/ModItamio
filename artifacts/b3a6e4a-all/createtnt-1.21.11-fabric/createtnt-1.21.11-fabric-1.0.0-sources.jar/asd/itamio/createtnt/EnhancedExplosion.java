package asd.itamio.createtnt;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1540;
import net.minecraft.class_1541;
import net.minecraft.class_1657;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2530;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_9892;
import org.jetbrains.annotations.Nullable;

/**
 * Enhanced explosion with separate block destruction and entity damage radii.
 *
 * <p>Unlike vanilla {@code Explosion}, block destruction reach and entity
 * damage reach are separate radii ({@code blockRadius} vs {@code entityRadius}),
 * exactly like a high-explosive blast. On completion it sends a
 * packet to clients so they render the big plume + blast wave particles.</p>
 *
 * <p>1.21.11: vanilla split explosions into the {@code Explosion} interface
 * plus the {@code ServerExplosion} implementation. We extend the latter purely
 * so this class satisfies the vanilla API surface (damage sources, block
 * callbacks, knockback collection); the blast logic below is entirely ours.</p>
 */
public class EnhancedExplosion extends class_9892 {

    private final class_3218 level;
    private final double x;
    private final double y;
    private final double z;
    private final class_1297 exploder;
    /** Block destruction radius. */
    private final float blockRadius;
    /** Entity damage radius. */
    private final float entityRadius;
    private final boolean damagesTerrain;
    private final List<class_2338> affectedBlockPositions;
    private final Map<class_1657, class_243> playerKnockbackMap;
    /** TNT block positions collected during the blast, for simultaneous
     *  chain detonation. */
    private final List<class_2338> chainedTNTPositions = new java.util.ArrayList<>();

    /** Maps each affected block position to the maximum remaining ray energy
     *  at that position. Used to scale launch velocity: blocks behind resistant
     *  walls have very little energy left and barely move, while blocks in the
     *  open retain most of the energy and fly far. */
    private final Map<class_2338, Float> blockEnergyMap = new java.util.HashMap<>();

    /** Particle sizing power — decoupled from destruction power so the
     *  random TNT strength multiplier doesn't make particles absurdly big.
     *  Scales gently: a 3x-strength blast is only ~1.5x bigger visually. */
    private final float particlePower;
    /** Plume axis for the explosion visual packet; defaults to world up. */
    private float plumeAxisX = 0.0F;
    private float plumeAxisY = 1.0F;
    private float plumeAxisZ = 0.0F;

    public void setPlumeAxis(float x, float y, float z) {
        this.plumeAxisX = x;
        this.plumeAxisY = y;
        this.plumeAxisZ = z;
    }

    public EnhancedExplosion(class_1937 level, @Nullable class_1297 entity, double x, double y, double z,
                             float blockRadius, float entityRadius, boolean causesFire, boolean damagesTerrain) {
        this(level, entity, x, y, z, blockRadius, entityRadius, causesFire, damagesTerrain, blockRadius);
    }

    public EnhancedExplosion(class_1937 level, @Nullable class_1297 entity, double x, double y, double z,
                             float blockRadius, float entityRadius, boolean causesFire, boolean damagesTerrain,
                             float particlePower) {
        // 1.21.11 ServerExplosion ctor: no particle/sound args anymore (the
        // server picks those itself); the center is a Vec3.
        super((class_3218) level, entity, null, null, new class_243(x, y, z), blockRadius, causesFire,
            damagesTerrain ? class_1927.class_4179.field_40879 : class_1927.class_4179.field_40878);
        this.level = (class_3218) level;
        this.exploder = entity;
        this.x = x;
        this.y = y;
        this.z = z;
        this.blockRadius = blockRadius;
        this.entityRadius = entityRadius;
        this.damagesTerrain = damagesTerrain;
        this.particlePower = particlePower;
        this.affectedBlockPositions = Lists.newArrayList();
        this.playerKnockbackMap = Maps.newHashMap();
    }

    /**
     * Part 1: compute destroyed blocks and deal entity damage/knockback.
     * Block reach uses {@link #blockRadius}, entity reach uses {@link #entityRadius}.
     *
     * <p>Named {@code detonate} rather than {@code explode} because the parent
     * {@code ServerExplosion} already has an {@code explode()} with a different
     * signature (returns the destroyed-block count); the vanilla one is never
     * called — our two-phase pipeline replaces it.</p>
     */
    public void detonate() {
        Set<class_2338> set = Sets.newHashSet();

        // Block destruction sampling (same ray-cast approach as vanilla,
        // but the reach is blockRadius).
        for (int j = 0; j < 16; ++j) {
            for (int k = 0; k < 16; ++k) {
                for (int l = 0; l < 16; ++l) {
                    if (j == 0 || j == 15 || k == 0 || k == 15 || l == 0 || l == 15) {
                        double d0 = (double) ((float) j / 15.0F * 2.0F - 1.0F);
                        double d1 = (double) ((float) k / 15.0F * 2.0F - 1.0F);
                        double d2 = (double) ((float) l / 15.0F * 2.0F - 1.0F);
                        double d3 = Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
                        d0 = d0 / d3;
                        d1 = d1 / d3;
                        d2 = d2 / d3;
                        float f = this.blockRadius * (0.7F + this.level.method_8409().method_43057() * ModConfig.rayReachVariation);
                        double d4 = this.x;
                        double d6 = this.y;
                        double d8 = this.z;
                        class_2338 lastBlock = null;

                        for (float f1 = 0.3F; f > 0.0F; f -= ModConfig.rayStepDecay) {
                            class_2338 blockpos = class_2338.method_49637(d4, d6, d8);

                            // --- Energy transfer: per-block shock absorption ---
                            // The ray carries the TNT's shock energy. When the
                            // shock enters a NEW block (the 0.3-step march can
                            // sample the same block several times — absorb only
                            // on first entry so capacity is per-block, not
                            // per-step), the block absorbs as much energy as it
                            // can handle:
                            //   capacity = (blastResistance + base) * multiplier
                            // If the shock exceeds the capacity, the block
                            // explodes and the shock continues weakened by
                            // exactly the absorbed amount (E -= capacity).
                            // Otherwise the block absorbs the entire shock and
                            // SURVIVES — the ray ends here.
                            if (!blockpos.equals(lastBlock)) {
                                lastBlock = blockpos;
                                class_2680 state = this.level.method_8320(blockpos);

                                if (!state.method_26215()) {
                                    float resistance = state.method_26204().method_9520();

                                    // Unbreakable blocks (bedrock, barriers)
                                    // absorb the whole shock and never explode.
                                    if (resistance < 0.0F) {
                                        break;
                                    }

                                    float capacity = (resistance + ModConfig.resistanceBase)
                                        * ModConfig.energyAbsorptionMultiplier;

                                    if (f > capacity) {
                                        // Shock overwhelms the block: it explodes.
                                        set.add(blockpos);
                                        // Track the residual shock energy
                                        // after absorption (drives debris
                                        // launch speed). Keep the max when
                                        // several rays hit the same block.
                                        float residual = f - capacity;
                                        Float existing = this.blockEnergyMap.get(blockpos);
                                        if (existing == null || residual > existing) {
                                            this.blockEnergyMap.put(blockpos, residual);
                                        }
                                        // The block cancels its capacity worth
                                        // of explosion energy; the weakened
                                        // shock travels on.
                                        f -= capacity;
                                    } else {
                                        // Block absorbs the entire remaining
                                        // shock and survives. Ray ends.
                                        break;
                                    }
                                }
                            }

                            d4 += d0 * 0.30000001192092896D;
                            d6 += d1 * 0.30000001192092896D;
                            d8 += d2 * 0.30000001192092896D;
                        }
                    }
                }
            }
        }

        this.affectedBlockPositions.addAll(set);

        // Explicitly add all fluid SOURCE blocks within the explosion radius.
        // The ray-cast sampling above may miss fluid blocks because fluids
        // have huge blast resistance and stop rays instantly. Only source
        // blocks (LEVEL 0) are collected: flowing water (levels 1-7) is left
        // untouched — it drains/flows naturally once its sources are gone,
        // instead of being flung as weird partial-block scatter.
        // Skipped entirely when the user disables fluid scattering in the
        // config — fluids are then left untouched by the blast.
        if (ModConfig.scatterFluids) {
            int fluidR = class_3532.method_15386(this.blockRadius);
            for (int fx = -fluidR; fx <= fluidR; fx++) {
                for (int fy = -fluidR; fy <= fluidR; fy++) {
                    for (int fz = -fluidR; fz <= fluidR; fz++) {
                        if (fx * fx + fy * fy + fz * fz <= fluidR * fluidR) {
                            class_2338 fpos = class_2338.method_49637(
                                (int) this.x + fx, (int) this.y + fy, (int) this.z + fz);
                            class_2680 fstate = this.level.method_8320(fpos);
                            if (fstate.method_26204() instanceof class_2404
                                && (fstate.method_26227().method_15767(class_3486.field_15517)
                                    || fstate.method_26227().method_15767(class_3486.field_15518))
                                && fstate.method_11654(class_2404.field_11278) == 0) {
                                set.add(fpos);
                            }
                        }
                    }
                }
            }
        }
        // Re-add in case any new fluid positions were found.
        for (class_2338 fp : set) {
            if (!this.affectedBlockPositions.contains(fp)) {
                this.affectedBlockPositions.add(fp);
            }
        }

        float f3 = this.entityRadius * 2.0F;
        int k1 = class_3532.method_15357(this.x - (double) f3 - 1.0D);
        int l1 = class_3532.method_15357(this.x + (double) f3 + 1.0D);
        int i2 = class_3532.method_15357(this.y - (double) f3 - 1.0D);
        int i1 = class_3532.method_15357(this.y + (double) f3 + 1.0D);
        int j2 = class_3532.method_15357(this.z - (double) f3 - 1.0D);
        int j1 = class_3532.method_15357(this.z + (double) f3 + 1.0D);
        List<class_1297> list = this.level.method_8335(this.exploder,
            new class_238(k1, i2, j2, l1, i1, j1));
        class_243 vec3 = new class_243(this.x, this.y, this.z);

        for (int k2 = 0; k2 < list.size(); ++k2) {
            class_1297 entity = list.get(k2);

            if (!entity.method_5659(this)) {
                double d12 = Math.sqrt(entity.method_5649(this.x, this.y, this.z)) / (double) f3;

                if (d12 <= 1.0D) {
                    // Already-ignited TNT entities are SCATTERED (moved like
                    // regular blocks) instead of detonated. Apply knockback
                    // velocity away from the blast center so they fly outward.
                    // Their fuse continues counting down naturally — they may
                    // explode mid-flight if their fuse runs out.
                    if (entity instanceof class_1541) {
                        double tdx = entity.method_23317() - this.x;
                        double tdy = entity.method_23318() + (double) entity.method_5751() - this.y;
                        double tdz = entity.method_23321() - this.z;
                        double tdist = (double) class_3532.method_15355((float) (tdx * tdx + tdy * tdy + tdz * tdz));
                        if (tdist != 0.0D) {
                            tdx = tdx / tdist;
                            tdy = tdy / tdist;
                            tdz = tdz / tdist;
                            double tdensity = (double) class_9892.method_61731(vec3, entity);
                            double tpush = (1.0D - d12) * tdensity * ModConfig.entityKnockbackScale;
                            entity.method_18799(entity.method_18798().method_1031(
                                tdx * tpush * 2.0D,
                                tdy * tpush * 2.0D + 0.3D * ModConfig.entityKnockbackScale,
                                tdz * tpush * 2.0D));
                        }
                        continue;
                    }

                    // Falling blocks from previous explosions are immune to damage
                    // but accumulate additional velocity from this explosion. This
                    // means chain TNT detonations boost existing flying debris
                    // instead of destroying it, and reset the fall timer so the
                    // blocks don't vanish mid-air.
                    if (entity instanceof class_1540) {
                        double d5 = entity.method_23317() - this.x;
                        double d7 = entity.method_23318() + (double) entity.method_5751() - this.y;
                        double d9 = entity.method_23321() - this.z;
                        double d13 = (double) class_3532.method_15355((float) (d5 * d5 + d7 * d7 + d9 * d9));
                        if (d13 != 0.0D) {
                            d5 = d5 / d13;
                            d7 = d7 / d13;
                            d9 = d9 / d13;
                            double d14 = (double) class_9892.method_61731(vec3, entity);
                            double d10 = (1.0D - d12) * d14 * ModConfig.entityKnockbackScale;
                            // Accumulate velocity — additive so energy builds up
                            // across multiple explosions. Reduced multiplier so
                            // chain explosions don't fling debris too far.
                            entity.method_18799(entity.method_18798().method_1031(
                                d5 * d10 * 1.0D,
                                d7 * d10 * 1.0D + 0.15D * ModConfig.entityKnockbackScale,
                                d9 * d10 * 1.0D));
                        }
                        // Reset the fall timer so the block doesn't expire mid-air.
                        ((class_1540) entity).field_7192 = 0;
                        continue;
                    }

                    double d5 = entity.method_23317() - this.x;
                    double d7 = entity.method_23318() + (double) entity.method_5751() - this.y;
                    double d9 = entity.method_23321() - this.z;
                    double d13 = (double) class_3532.method_15355((float) (d5 * d5 + d7 * d7 + d9 * d9));

                    if (d13 != 0.0D) {
                        double d14 = (double) class_9892.method_61731(vec3, entity);
                        double d10 = (1.0D - d12) * d14;
                        // Entity damage formula: (d^2 + d)/2 * 7 * radius + 1
                        entity.method_64419(this.level.method_48963().method_48807(this),
                            (float) ((int) ((d10 * d10 + d10) / 2.0D * 7.0D * (double) f3 + 1.0D)));
                        double d11 = d10;

                        // (Blast-protection knockback dampening dropped — the
                        // mod already scales entity knockback down heavily.)

                        // 360° omnidirectional push: normalize the horizontal (X/Z)
                        // direction independently from Y so entities are always pushed
                        // away from the blast horizontally, regardless of height
                        // difference. This prevents the push from being mostly
                        // vertical when the entity is at the same Y as the TNT.
                        double horizDist = (double) class_3532.method_15355((float) (d5 * d5 + d9 * d9));
                        double pushX, pushY, pushZ;

                        if (horizDist > 0.01D) {
                            // Normalized horizontal direction (360° outward).
                            pushX = d5 / horizDist;
                            pushZ = d9 / horizDist;
                        } else {
                            // Entity is directly above/below the blast — pick a
                            // random horizontal direction so they still get pushed
                            // outward instead of only straight up/down.
                            float angle = this.level.method_8409().method_43057() * 6.2831855F;
                            pushX = (double) class_3532.method_15362(angle);
                            pushZ = (double) class_3532.method_15374(angle);
                        }

                        // Y push: normalized vertical component, but capped so the
                        // horizontal push isn't overshadowed.
                        pushY = d7 / d13;
                        if (pushY > 0.6D) pushY = 0.6D;
                        if (pushY < -0.3D) pushY = -0.3D;

                        // Apply the push, scaled by entityKnockbackScale so
                        // entities are nudged rather than launched (default
                        // 0.35 = minimal scattering).
                        double pushStrength = d11 * 1.5D * ModConfig.entityKnockbackScale;
                        entity.method_18799(entity.method_18798().method_1031(
                            pushX * pushStrength,
                            pushY * pushStrength + 0.2D * ModConfig.entityKnockbackScale,
                            pushZ * pushStrength));

                        if (entity instanceof class_1657) {
                            class_1657 player = (class_1657) entity;

                            if (!player.method_7325()
                                && (!player.method_68878() || !player.method_31549().field_7479)) {
                                this.playerKnockbackMap.put(player,
                                    new class_243(pushX * d10 * ModConfig.entityKnockbackScale,
                                        pushY * d10 * ModConfig.entityKnockbackScale,
                                        pushZ * d10 * ModConfig.entityKnockbackScale));
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Part 2: destroy the affected blocks and tell clients to render the blast
     * particles. All affected solid blocks are destroyed in place (no block
     * scattering) to form the crater; TNT blocks are collected for chain
     * detonation; fluids are scattered as fluid entities / evaporated when
     * {@code scatterFluids} is enabled.
     */
    public void finalizeExplosion(boolean spawnParticles) {
        // The explosion sound is NOT played here. The
        // delayed blast wave particle plays the boom when the wave reaches each
        // player, giving the "shake + delayed sound" on impact.

        // Send the particle + knockback packet to every client in range.
        // Per-player knockback rides along with the packet and the client
        // applies it directly — server-side player motion is
        // client-authoritative and would be discarded anyway.
        sendExplosionToClients();

        if (this.damagesTerrain) {
            for (class_2338 blockpos : this.affectedBlockPositions) {
                class_2680 state = this.level.method_8320(blockpos);
                class_2248 block = state.method_26204();

                if (!state.method_26215()) {
                    boolean isFluid = state.method_26227().method_15767(class_3486.field_15517)
                        || state.method_26227().method_15767(class_3486.field_15518);
                    boolean isTNT = block instanceof class_2530;

                    if (isFluid && ModConfig.scatterFluids) {
                        // --- Energy at this fluid block (ray residual or
                        // distance fallback) — drives evaporation and the
                        // fluid launch speed.
                        double dx = (double) blockpos.method_10263() + 0.5D - this.x;
                        double dy = (double) blockpos.method_10264() + 0.5D - this.y;
                        double dz = (double) blockpos.method_10260() + 0.5D - this.z;
                        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                        Float storedEnergy = this.blockEnergyMap.get(blockpos);
                        double energyFactor;
                        if (storedEnergy != null) {
                            energyFactor = Math.max(0.1D, storedEnergy / this.blockRadius);
                        } else {
                            energyFactor = Math.max(0.3D, 1.0D - dist / (double) this.blockRadius);
                        }
                        double variation = 0.7D + this.level.method_8409().method_43058() * 0.6D;
                        energyFactor *= variation;

                        // --- Water evaporation ---
                        // Water blocks that receive enough blast energy —
                        // comparable to the energy needed to break cobblestone
                        // (a high-energy zone near the blast center) — have a
                        // 40% chance to "evaporate": the block is destroyed
                        // and drops nothing, simulating the blast flash-
                        // vaporizing the water. The remaining 60% scatter as
                        // falling water entities (existing behavior). Lava
                        // never evaporates; it always scatters.
                        boolean isWater = state.method_26227().method_15767(class_3486.field_15517);
                        float evapThreshold = this.blockRadius * ModConfig.waterEvaporationThreshold;
                        boolean highEnergy = (storedEnergy != null && storedEnergy >= evapThreshold)
                            || (storedEnergy == null
                                && (1.0D - dist / (double) this.blockRadius) >= 0.6D);
                        if (isWater && highEnergy && this.level.method_8409().method_43057() < ModConfig.waterEvaporationChance) {
                            // Evaporate: remove the water block, drop nothing.
                            this.level.method_8652(blockpos, class_2246.field_10124.method_9564(), 18);
                            continue;
                        }

                        // Remove the fluid block BEFORE spawning the entity.
                        // Flag 18 = 2 (client update) | 16 (skip neighbor
                        // notification) so neighboring fluids don't flow into
                        // the gap before the entity is spawned.
                        this.level.method_8652(blockpos, class_2246.field_10124.method_9564(), 18);

                        double baseSpeed = ModConfig.fluidLaunchSpeed * energyFactor;
                        double motionX, motionY, motionZ;
                        if (dist > 0.001D) {
                            motionX = (dx / dist) * baseSpeed;
                            motionY = (dy / dist) * baseSpeed + ModConfig.fluidUpwardBoost * energyFactor;
                            motionZ = (dz / dist) * baseSpeed;
                        } else {
                            motionX = 0.0D;
                            motionY = baseSpeed;
                            motionZ = 0.0D;
                        }
                        motionY = Math.min(motionY, ModConfig.fluidVelocityCapY);
                        motionX = Math.max(-ModConfig.fluidVelocityCapXZ, Math.min(ModConfig.fluidVelocityCapXZ, motionX));
                        motionZ = Math.max(-ModConfig.fluidVelocityCapXZ, Math.min(ModConfig.fluidVelocityCapXZ, motionZ));

                        EntityEnhancedFallingBlock entity = new EntityEnhancedFallingBlock(
                            this.level,
                            (double) ((float) blockpos.method_10263() + 0.5F),
                            (double) blockpos.method_10264(),
                            (double) ((float) blockpos.method_10260() + 0.5F),
                            state);
                        entity.method_18799(new class_243(motionX, motionY, motionZ));
                        this.level.method_8649(entity);
                    } else if (isTNT) {
                        // TNT blocks are collected for simultaneous chain
                        // detonation instead of calling onBlockExploded
                        // (which spawns primed TNTs with random fuses).
                        this.level.method_8652(blockpos, class_2246.field_10124.method_9564(), 18);
                        this.chainedTNTPositions.add(blockpos);
                    } else {
                        // Solid blocks are destroyed in place — no scattering.
                        // Greatly reduced item drop chance (1/4 of vanilla's
                        // already-low rate) so explosions vaporize most blocks
                        // instead of dropping them.
                        if (block.method_9533(this)
                            && this.level.method_8409().method_43057() < ModConfig.blockDropChance / this.blockRadius) {
                            class_2248.method_9610(state, this.level, blockpos, null);
                        }
                        this.level.method_8652(blockpos, class_2246.field_10124.method_9564(), 3);
                        block.method_9586(this.level, blockpos, this);
                    }
                }
            }
        }

        // Queue blocks adjacent to the crater for collapse checking. These are
        // the blocks that may have lost their structural support due to the
        // explosion. The collapse handler processes them over the next few ticks
        // (anchored support check + cascade), then stops when settled.
        Set<class_2338> affected = new HashSet<>(this.affectedBlockPositions);
        for (class_2338 pos : this.affectedBlockPositions) {
            for (int[] dir : ADJACENT) {
                class_2338 adj = pos.method_10069(dir[0], dir[1], dir[2]);
                if (!affected.contains(adj)) {
                    BlockCollapseHandler.queueCollapseCheck(this.level, adj);
                }
            }
        }
    }

    /** Returns TNT block positions collected during the blast for chain detonation. */
    public List<class_2338> getChainedTNTPositions() {
        return this.chainedTNTPositions;
    }

    private static final int[][] ADJACENT = {
        { 1, 0, 0}, {-1, 0, 0},
        { 0, 1, 0}, { 0,-1, 0},
        { 0, 0, 1}, { 0, 0,-1}
    };

    private void sendExplosionToClients() {
        // Plume = the block above the center is air and the block below is not.
        boolean isPlume = this.level.method_8320(class_2338.method_49637(this.x, this.y + 1, this.z)).method_26215()
            && !this.level.method_8320(class_2338.method_49637(this.x, this.y - 1, this.z)).method_26215();

        // Only players within distSqr < 263000 (~512 blocks) receive the
        // explosion packet, and each packet carries that player's own
        // knockback vector. ServerLevel.players() is already ServerPlayer-typed.
        for (class_3222 player : this.level.method_18456()) {
            double distSqr = player.method_5649(this.x, this.y, this.z);
            if (distSqr >= 263000.0D) {
                continue;
            }
            class_243 knockback = this.playerKnockbackMap.getOrDefault(player, class_243.field_1353);
            SpawnExplosionMessage msg = new SpawnExplosionMessage(this.x, this.y, this.z,
                this.particlePower, isPlume,
                (float) knockback.field_1352, (float) knockback.field_1351, (float) knockback.field_1350,
                this.plumeAxisX, this.plumeAxisY, this.plumeAxisZ);
            ModNetwork.sendExplosion(player, msg);
        }
    }

    @Override
    public Map<class_1657, class_243> method_61738() {
        return this.playerKnockbackMap;
    }

    /** The destroyed block positions (vanilla's old getToBlow equivalent). */
    public List<class_2338> getToBlow() {
        return this.affectedBlockPositions;
    }
}
