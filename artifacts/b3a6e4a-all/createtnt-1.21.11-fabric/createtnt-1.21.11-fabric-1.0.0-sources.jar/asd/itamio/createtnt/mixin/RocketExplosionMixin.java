package asd.itamio.createtnt.mixin;

import asd.itamio.createtnt.ModConfig;
import asd.itamio.createtnt.RocketTracker;
import net.minecraft.class_1671;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Redirects enabled crossbow/dispenser fireworks into enhanced blasts. */
@Mixin(class_1671.class)
public class RocketExplosionMixin {

    @Inject(method = "explode", at = @At("HEAD"), cancellable = true)
    private void createtnt$redirectBlast(class_3218 level, CallbackInfo ci) {
        class_1671 self = (class_1671) (Object) this;
        if (level.method_8608() || !self.method_7477() || !ModConfig.rocketShellExplosions) return;
        RocketTracker.detonateShell(level, self);
        RocketTracker.untrack(self.method_5667());
        ci.cancel();
    }
}
