package asd.itamio.createtnt;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3998;
import net.minecraft.class_4002;
import net.minecraft.class_4066;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

/**
 * Hidden controller particle that drives the explosion smoke cloud.
 *
 * <p>For its first 5 ticks ({@code PLUME_AGE}) it bursts
 * {@link ShellExplosionSmokeParticle} puffs around the blast center — 20 per
 * tick on the "All" particle setting, 10 on "Decreased", 5 on "Minimal"
 * (scaled by {@code baseSmokeAmount}) — while its trail sub-particles paint
 * the blast-ray streaks over up to 5 ticks. It renders nothing itself and
 * expires after 10 ticks.</p>
 *
 * <p>Spawn geometry: puffs get random gaussian-ish offsets and velocities,
 * ground blasts bias upward (the plume). The blast rays are laid out on a
 * jittered sphere lattice with a random global rotation per explosion, plus
 * 1-4 guaranteed tall pillar rays off the top.</p>
 */
public class ShellExplosionCloudParticle extends class_3998 {

    /** Ticks over which the controller spawns the primary plume puffs. */
    private static final int PLUME_AGE = 5;

    private final float power;
    private final List<TrailSubparticle> trails = new LinkedList<>();
    private final boolean isPlume;
    private final class_4002 sprites;
    /** Plume axis (unit): the "up" the plume grows along. (0,1,0) = straight up. */
    private final double ax, ay, az;
    /** Orthonormal basis (u, axis, w): local plume space -> world space. */
    private final double ux, uy, uz, wx, wy, wz;

    ShellExplosionCloudParticle(class_638 level, double x, double y, double z,
                                float power, boolean isPlume,
                                float axisX, float axisY, float axisZ, class_4002 sprites) {
        super(level, x, y, z);
        // Zero velocity; the controller itself renders nothing.
        this.field_3852 = 0.0D;
        this.field_3869 = 0.0D;
        this.field_3850 = 0.0D;
        this.field_3844 = 0.0F;
        this.field_3862 = false;
        this.power = power;
        this.isPlume = isPlume;
        this.sprites = sprites;
        double nax = axisX, nay = axisY, naz = axisZ;
        double alen = Math.sqrt(nax * nax + nay * nay + naz * naz);
        if (alen < 1.0E-4D) {
            nax = 0.0D; nay = 1.0D; naz = 0.0D; alen = 1.0D;
        }
        nax /= alen; nay /= alen; naz /= alen;
        this.ax = nax; this.ay = nay; this.az = naz;
        double bux, buy, buz, bwx, bwy, bwz;
        if (nax == 0.0D && naz == 0.0D && nay > 0.0D) {
            bux = 1.0D; buy = 0.0D; buz = 0.0D;
            bwx = 0.0D; bwy = 0.0D; bwz = 1.0D;
        } else {
            double hx = 0.0D, hy = 1.0D, hz = 0.0D;
            if (Math.abs(nay) > 0.9D) { hx = 1.0D; hy = 0.0D; hz = 0.0D; }
            bux = nay * hz - naz * hy;
            buy = naz * hx - nax * hz;
            buz = nax * hy - nay * hx;
            double ulen = Math.sqrt(bux * bux + buy * buy + buz * buz);
            bux /= ulen; buy /= ulen; buz /= ulen;
            bwx = nay * buz - naz * buy;
            bwy = naz * bux - nax * buz;
            bwz = nax * buy - nay * bux;
        }
        this.ux = bux; this.uy = buy; this.uz = buz;
        this.wx = bwx; this.wy = bwy; this.wz = bwz;
        // The controller expires after 10 ticks.
        this.field_3847 = 10;

        // Blast-ray trails can be disabled in the config.
        if (ModConfig.showExtraShellExplosionTrails) {
            double secondaryVelScale = this.power * 0.35D;
            // Blast-ray counts scale with the in-game particle setting:
            // ALL 12+rand(6), DECREASED 6+rand(3), MINIMAL 4.
            int secondaryCount;
            switch (getParticleStatus()) {
                case field_18197: secondaryCount = 12 + this.field_3840.method_43048(6); break;
                case field_18198: secondaryCount = 6 + this.field_3840.method_43048(3); break;
                default: secondaryCount = 4; break;
            }
            secondaryCount = Math.max(1, (int) (secondaryCount * ModConfig.explosionTrailMultiplier));
            double gravity = this.isPlume ? -0.5D : -0.1D;

            // Distribute the blast-ray directions evenly across a sphere
            // (Fibonacci lattice) with per-ray jitter and a random global
            // rotation per explosion — so every explosion looks different,
            // each line shoots out in its own direction, and no two lines
            // start out touching each other.
            double goldenAngle = Math.PI * (3.0D - Math.sqrt(5.0D));
            double rotYaw = this.field_3840.method_43058() * Math.PI * 2.0D;
            double rotTilt = this.field_3840.method_43058() * (this.isPlume ? 0.5D : Math.PI);
            double cosYaw = Math.cos(rotYaw);
            double sinYaw = Math.sin(rotYaw);
            double cosTilt = Math.cos(rotTilt);
            double sinTilt = Math.sin(rotTilt);

            for (int i = 0; i < secondaryCount; ++i) {
                double dy = secondaryCount <= 1 ? 0.0D
                    : 1.0D - 2.0D * (double) i / (double) (secondaryCount - 1);
                double r = Math.sqrt(Math.max(0.0D, 1.0D - dy * dy));
                double theta = goldenAngle * (double) i;
                double dx = Math.cos(theta) * r;
                double dz = Math.sin(theta) * r;
                // Per-ray jitter off the perfect lattice (keeps it organic).
                dx += (this.field_3840.method_43058() - this.field_3840.method_43058()) * 0.35D;
                dy += (this.field_3840.method_43058() - this.field_3840.method_43058()) * 0.35D;
                dz += (this.field_3840.method_43058() - this.field_3840.method_43058()) * 0.35D;
                // Ground blasts send their rays upward (the plume case).
                if (this.isPlume) {
                    dy = Math.abs(dy);
                }
                // Random global rotation: yaw, then tilt.
                double tx = dx * cosYaw + dz * sinYaw;
                double tz = dz * cosYaw - dx * sinYaw;
                double ty = dy * cosTilt - tz * sinTilt;
                tz = dy * sinTilt + tz * cosTilt;
                dx = tx;
                dy = ty;
                dz = tz;
                // Normalize to a unit direction.
                double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (len < 1.0E-4D) {
                    dx = 0.0D;
                    dy = 1.0D;
                    dz = 0.0D;
                    len = 1.0D;
                }
                dx /= len;
                dy /= len;
                dz /= len;

                double speed = 0.4D + this.field_3840.method_43058() * 0.6D;
                class_243 vel = new class_243(dx * speed, dy * speed, dz * speed).method_1021(secondaryVelScale);
                // Start each ray slightly out along its own direction so the
                // lines read as clearly separated streaks from the core.
                class_243 displacement = new class_243(dx, dy, dz)
                    .method_1021(1.0D + this.field_3840.method_43058() * 1.5D);
                int lifetime = 5;
                this.trails.add(new TrailSubparticle(displacement, vel, 0.85D, gravity, lifetime));
            }

            // --- Guaranteed pillar rays ---
            // Every explosion gets 1-4 long pillar rays climbing off the top
            // in random steep directions — EVERY one is 15-25 blocks tall.
            // Their puffs are heat-boosted so the pillars keep rising after
            // the streak.
            int pillarCount = 1 + this.field_3840.method_43048(4);
            for (int i = 0; i < pillarCount; ++i) {
                this.addPillarRay(secondaryVelScale, 15.0D, 25.0D);
            }
        }
    }

    /**
     * Adds one guaranteed long pillar ray climbing off the top of the blast in
     * a random steep direction. The speed is derived FROM the target length
     * (over the trail's 5-tick geometric travel at drag 0.85 ≈ 3.708x
     * velocity), so the requested length holds at any explosion power.
     * Pillar puffs get a heat boost in the trail spawn loop so they keep
     * rising after the streak.
     */
    private void addPillarRay(double velScale, double minLength, double maxLength) {
        double azimuth = this.field_3840.method_43058() * Math.PI * 2.0D;
        double elevation = 1.047D + this.field_3840.method_43058() * 0.489D; // 60-88 degrees
        double dx = Math.cos(elevation) * Math.cos(azimuth);
        double dy = Math.sin(elevation);
        double dz = Math.cos(elevation) * Math.sin(azimuth);
        double targetLength = minLength + this.field_3840.method_43058() * (maxLength - minLength);
        double speed = targetLength / (3.708D * velScale);
        class_243 vel = new class_243(dx * speed, dy * speed, dz * speed).method_1021(velScale);
        class_243 displacement = new class_243(dx, dy, dz)
            .method_1021(1.0D + this.field_3840.method_43058() * 1.5D);
        // Near-zero trail gravity so the pillar climbs straight instead of sagging.
        this.trails.add(new TrailSubparticle(displacement, vel, 0.85D, -0.05D, 5, true));
    }

    @Override
    public void method_3070() {
        if (this.field_3866 < PLUME_AGE) {
            float primaryScale = this.power * 2.0F;
            int plumes;
            switch (getParticleStatus()) {
                case field_18197: plumes = 20; break;
                case field_18198: plumes = 10; break;
                default: plumes = 5; break;
            }
            // Base smoke amount multiplier (0.45 = about half the default density).
            plumes = Math.max(1, (int) (plumes * ModConfig.baseSmokeAmount));
            double velScale = this.power * 0.25D;
            velScale *= 1.0D - (float) this.field_3866 / (float) PLUME_AGE;
            double displacementScale = this.power * 0.35D;
            for (int i = 0; i <= plumes; ++i) {
                double lox = (this.field_3840.method_43058() - this.field_3840.method_43058()) * displacementScale;
                double loy = this.field_3840.method_43058() - this.field_3840.method_43058();
                if (this.isPlume) {
                    loy = Math.abs(loy);
                }
                loy *= displacementScale;
                double loz = (this.field_3840.method_43058() - this.field_3840.method_43058()) * displacementScale;
                double ldx = (this.field_3840.method_43058() - this.field_3840.method_43058()) * velScale;
                double ldy = this.field_3840.method_43058() - this.field_3840.method_43058();
                if (this.isPlume) {
                    ldy += 1.2D;
                }
                ldy *= velScale;
                double ldz = (this.field_3840.method_43058() - this.field_3840.method_43058()) * velScale;
                double rx = this.field_3874 + (this.ux * lox + this.ax * loy + this.wx * loz) + this.ax * 0.5D;
                double ry = this.field_3854 + (this.uy * lox + this.ay * loy + this.wy * loz) + this.ay * 0.5D;
                double rz = this.field_3871 + (this.uz * lox + this.az * loy + this.wz * loz) + this.az * 0.5D;
                double dx = this.ux * ldx + this.ax * ldy + this.wx * ldz;
                double dy = this.uy * ldx + this.ay * ldy + this.wy * ldz;
                double dz = this.uz * ldx + this.az * ldy + this.wz * ldz;
                // Base smoke lifetime: 7 seconds (140 ticks) — the large
                // puffs disappear around the same time as the ray puffs.
                int lifetime = 140;
                this.field_3851.method_8466(new ShellSmokeOption(lifetime, primaryScale),
                    true, rx, ry, rz, dx, dy, dz);
            }
        }

        int trailSteps = getParticleStatus() == class_4066.field_18197 ? 2 : 1;
        float secondaryScale = this.power * 0.75F;
        for (Iterator<TrailSubparticle> iter = this.trails.iterator(); iter.hasNext(); ) {
            TrailSubparticle trail = iter.next();
            if (this.field_3866 > trail.lifetime) {
                iter.remove();
                continue;
            }
            class_243 localOrigin = trail.calculateDisplacement(this.field_3866);
            class_243 localNext = trail.calculateDisplacement(this.field_3866 + 1);
            class_243 origin = toWorld(localOrigin).method_1031(0.0D, trail.gravity * this.field_3866, 0.0D);
            class_243 next = toWorld(localNext).method_1031(0.0D, trail.gravity * (this.field_3866 + 1), 0.0D);
            double velScale = 0.125D;
            // Wide spawn spread so ray puffs form soft wisps instead of sharp
            // radiate lines with gaps between them.
            double displacementScale = 0.3D;
            // Pillar rays travel 10-16 blocks per tick — with only a few
            // puffs per tick they would be sparse dotted lines. Spawn enough
            // puffs per tick to keep the whole pillar densely filled.
            int steps = trailSteps;
            if (trail.pillar) {
                double stepDist = origin.method_1022(next);
                steps = Math.min(40, Math.max(2,
                    (int) Math.ceil(stepDist / ModConfig.pillarTrailSpacing)));
            }
            for (int i = 0; i <= steps; ++i) {
                class_243 pos = origin.method_35590(next, (double) i / (double) steps)
                    .method_1031(this.field_3874, this.field_3854, this.field_3871);
                double rx = pos.field_1352 + (this.field_3840.method_43058() - this.field_3840.method_43058()) * displacementScale;
                double ry = pos.field_1351 + (this.field_3840.method_43058() - this.field_3840.method_43058()) * displacementScale;
                double rz = pos.field_1350 + (this.field_3840.method_43058() - this.field_3840.method_43058()) * displacementScale;
                double dx = (this.field_3840.method_43058() - this.field_3840.method_43058()) * velScale;
                double dy = (this.field_3840.method_43058() - this.field_3840.method_43058()) * velScale;
                double dz = (this.field_3840.method_43058() - this.field_3840.method_43058()) * velScale;
                // Ray puffs: static for 2s, then scatter outward at their own
                // constant small speed; they live ~70% of the base smoke's
                // stay (set inside markAsRay).
                ShellExplosionSmokeParticle puff = new ShellExplosionSmokeParticle(
                    this.field_3851, rx, ry, rz, dx, dy, dz, this.sprites, 140, secondaryScale);
                puff.markAsRay(this.field_3874, this.field_3854, this.field_3871);
                // Pillar-ray puffs run hotter so the guaranteed tall rays
                // keep climbing after the initial streak.
                if (trail.pillar) {
                    puff.boostHeat(1.6F);
                }
                class_310.method_1551().field_1713.method_3058(puff);
            }
        }

        // Age the (invisible, motionless) controller so it expires after its
        // 10-tick lifetime.
        super.method_3070();
    }

    private class_243 toWorld(class_243 local) {
        return new class_243(
            this.ux * local.field_1352 + this.ax * local.field_1351 + this.wx * local.field_1350,
            this.uy * local.field_1352 + this.ay * local.field_1351 + this.wy * local.field_1350,
            this.uz * local.field_1352 + this.az * local.field_1351 + this.wz * local.field_1350);
    }

    /** The in-game particle setting: ALL, DECREASED, or MINIMAL. */
    private static class_4066 getParticleStatus() {
        return class_310.method_1551().field_1690.method_42475().method_41753();
    }

    /** Provider creating the controller from its option data. */
    public static class Provider implements class_707<ShellCloudOption> {
        private final class_4002 sprites;

        public Provider(class_4002 sprites) {
            this.sprites = sprites;
        }

        @Override
        public class_703 createParticle(ShellCloudOption data, class_638 level, double x, double y,
                                       double z, double xSpeed, double ySpeed, double zSpeed) {
            return new ShellExplosionCloudParticle(level, x, y, z, data.scale(), data.isPlume(),
                data.axisX(), data.axisY(), data.axisZ(), this.sprites);
        }
    }

    /** A straight-line smoke-streak trajectory with drag and gravity. */
    private static final class TrailSubparticle {
        private final class_243 displacement;
        private final class_243 vel;
        private final double drag;
        private final double gravity;
        private final int lifetime;
        /** True for the guaranteed tall pillar rays (denser trails). */
        private final boolean pillar;

        private TrailSubparticle(class_243 displacement, class_243 vel, double drag, double gravity, int lifetime) {
            this(displacement, vel, drag, gravity, lifetime, false);
        }

        private TrailSubparticle(class_243 displacement, class_243 vel, double drag, double gravity,
                                 int lifetime, boolean pillar) {
            this.displacement = displacement;
            this.vel = vel;
            this.drag = drag;
            this.gravity = gravity;
            this.lifetime = lifetime;
            this.pillar = pillar;
        }

        private class_243 calculateDisplacement(int ticks) {
            if (ticks <= 0) {
                return this.displacement;
            }
            if (this.drag == 1.0D) {
                return this.displacement.method_1019(this.vel.method_1021((double) ticks));
            }
            double geo = (1.0D - Math.pow(this.drag, ticks)) / (1.0D - this.drag);
            return this.displacement.method_1019(this.vel.method_1021(geo));
        }
    }
}
