package asd.itamio.createtnt;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1671;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/** Tracks crossbow/dispenser firework rockets for acceleration and visuals. */
public final class RocketTracker {
    private static final double ACCEL = 0.025D;
    private static final double MAX_SPEED = 3.0D;
    private static final int MAX_TRACK_AGE = 1200;
    private static final int MAX_TRACKED = 200;
    private static final double RANGE_SQR = 1.0E8D;

    private static final class Tracked {
        final class_3218 level;
        final class_1297 rocket;
        double x, y, z, mx, my, mz;
        int age;

        Tracked(class_3218 level, class_1297 rocket) {
            this.level = level;
            this.rocket = rocket;
            snapshot();
        }

        void snapshot() {
            x = rocket.method_23317(); y = rocket.method_23318(); z = rocket.method_23321();
            class_243 motion = rocket.method_18798();
            mx = motion.field_1352; my = motion.field_1351; mz = motion.field_1350;
        }
    }

    private static final Map<UUID, Tracked> TRACKED = new LinkedHashMap<>();

    private RocketTracker() {
    }

    public static void track(class_3218 level, class_1671 rocket) {
        if (TRACKED.size() < MAX_TRACKED) {
            TRACKED.putIfAbsent(rocket.method_5667(), new Tracked(level, rocket));
        }
    }

    public static void untrack(UUID id) {
        TRACKED.remove(id);
    }

    public static void tickAll() {
        if (TRACKED.isEmpty()) return;
        boolean enabled = ModConfig.rocketShellExplosions;
        Iterator<Map.Entry<UUID, Tracked>> it = TRACKED.entrySet().iterator();
        while (it.hasNext()) {
            Tracked tr = it.next().getValue();
            if (tr.rocket.method_31481()) {
                if (enabled) sendDirectionalVisual(tr);
                it.remove();
                continue;
            }
            if (tr.age > MAX_TRACK_AGE) {
                it.remove();
                continue;
            }
            tr.snapshot();
            tr.age++;
            if (!enabled) continue;
            class_243 motion = tr.rocket.method_18798();
            double speed = motion.method_1033();
            if (speed > 1.0E-4D && speed < MAX_SPEED) {
                class_243 dir = motion.method_1029();
                tr.rocket.method_18799(motion.method_1019(dir.method_1021(Math.min(ACCEL, MAX_SPEED - speed))));
            }
            tr.level.method_14199(new ShellSmokeOption(60, 1.5F), tr.x, tr.y, tr.z,
                2, 0.1D, 0.1D, 0.1D, 0.0D);
        }
    }

    private static void sendDirectionalVisual(Tracked tr) {
        double len = Math.sqrt(tr.mx * tr.mx + tr.my * tr.my + tr.mz * tr.mz);
        float axisX = 0.0F, axisY = 1.0F, axisZ = 0.0F;
        if (len >= 1.0E-4D) {
            axisX = (float) (-tr.mx / len);
            axisY = (float) (-tr.my / len);
            axisZ = (float) (-tr.mz / len);
        }
        float power = 3.0F * (ModConfig.tntStrength / 4.0F);
        for (class_3222 player : tr.level.method_18456()) {
            if (player.method_5649(tr.x, tr.y, tr.z) >= RANGE_SQR) continue;
            ModNetwork.sendExplosion(player, new SpawnExplosionMessage(tr.x, tr.y, tr.z,
                power, true, 0.0F, 0.0F, 0.0F, axisX, axisY, axisZ));
        }
    }
}
