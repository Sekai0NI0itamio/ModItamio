package asd.itamio.createtnt;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2540;

/** Particle options for the big explosion smoke puff: lifetime + size scale. */
public record ShellSmokeOption(int lifetime, float scale) implements class_2394 {

    public static final class_2394.class_2395<ShellSmokeOption> DESERIALIZER =
        new class_2394.class_2395<>() {
            @Override
            public ShellSmokeOption method_10296(class_2396<ShellSmokeOption> type, StringReader reader)
                throws CommandSyntaxException {
                reader.expect(' ');
                int lifetime = reader.readInt();
                reader.expect(' ');
                float scale = reader.readFloat();
                return new ShellSmokeOption(lifetime, scale);
            }

            @Override
            public ShellSmokeOption method_10297(class_2396<ShellSmokeOption> type, class_2540 buf) {
                return new ShellSmokeOption(buf.method_10816(), buf.readFloat());
            }
        };

    @Override
    public void method_10294(class_2540 buf) {
        buf.method_10804(this.lifetime);
        buf.writeFloat(this.scale);
    }

    @Override
    public String method_10293() {
        return this.lifetime + " " + this.scale;
    }

    @Override
    public class_2396<?> method_10295() {
        return BetterTNTs.SHELL_EXPLOSION_SMOKE;
    }
}
