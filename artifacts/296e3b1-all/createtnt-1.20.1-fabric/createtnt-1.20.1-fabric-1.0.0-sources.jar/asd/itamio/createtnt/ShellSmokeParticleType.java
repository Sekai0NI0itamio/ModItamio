package asd.itamio.createtnt;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2396;

/** ParticleType carrying {@link ShellSmokeOption} (lifetime + scale + trail flag). */
public class ShellSmokeParticleType extends class_2396<ShellSmokeOption> {

    public ShellSmokeParticleType() {
        super(false, ShellSmokeOption.DESERIALIZER);
    }

    @Override
    public Codec<ShellSmokeOption> method_29138() {
        return RecordCodecBuilder.create(i -> i.group(
            Codec.INT.fieldOf("lifetime").forGetter(ShellSmokeOption::lifetime),
            Codec.FLOAT.fieldOf("scale").forGetter(ShellSmokeOption::scale),
            Codec.BOOL.optionalFieldOf("trail", false).forGetter(ShellSmokeOption::trail))
            .apply(i, ShellSmokeOption::new));
    }
}
