package asd.itamio.createtnt;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2540;

/** Particle options for the explosion cloud controller: scale, plume flag, plume axis. */
public record ShellCloudOption(float scale, boolean isPlume, float axisX, float axisY, float axisZ)
    implements class_2394 {

    public static final class_2394.class_2395<ShellCloudOption> DESERIALIZER =
        new class_2394.class_2395<>() {
            @Override
            public ShellCloudOption method_10296(class_2396<ShellCloudOption> type, StringReader reader)
                throws CommandSyntaxException {
                reader.expect(' ');
                float scale = reader.readFloat();
                reader.expect(' ');
                boolean isPlume = reader.readBoolean();
                reader.expect(' ');
                float axisX = reader.readFloat();
                reader.expect(' ');
                float axisY = reader.readFloat();
                reader.expect(' ');
                float axisZ = reader.readFloat();
                return new ShellCloudOption(scale, isPlume, axisX, axisY, axisZ);
            }

            @Override
            public ShellCloudOption method_10297(class_2396<ShellCloudOption> type, class_2540 buf) {
                return new ShellCloudOption(buf.readFloat(), buf.readBoolean(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat());
            }
        };

    @Override
    public void method_10294(class_2540 buf) {
        buf.writeFloat(this.scale);
        buf.writeBoolean(this.isPlume);
        buf.writeFloat(this.axisX);
        buf.writeFloat(this.axisY);
        buf.writeFloat(this.axisZ);
    }

    @Override
    public String method_10293() {
        return this.scale + " " + this.isPlume + " " + this.axisX + " " + this.axisY + " " + this.axisZ;
    }

    @Override
    public class_2396<?> method_10295() {
        return BetterTNTs.SHELL_EXPLOSION_CLOUD;
    }
}
