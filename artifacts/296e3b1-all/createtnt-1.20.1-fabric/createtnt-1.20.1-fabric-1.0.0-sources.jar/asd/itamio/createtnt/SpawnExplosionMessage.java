package asd.itamio.createtnt;

import net.minecraft.class_2540;

/**
 * Tells the client to render the explosion at a given position.
 *
 * <p>The packet carries the explosion {@code power} (particle sizing scale)
 * and the receiving player's knockback vector, which the client applies
 * directly to its own player entity (player motion is client-authoritative).</p>
 */
public class SpawnExplosionMessage {

    private final double x, y, z;
    private final float power;
    private final boolean isPlume;
    private final float knockbackX, knockbackY, knockbackZ;
    private final float axisX, axisY, axisZ;

    public SpawnExplosionMessage(double x, double y, double z, float power, boolean isPlume,
                                 float knockbackX, float knockbackY, float knockbackZ) {
        this(x, y, z, power, isPlume, knockbackX, knockbackY, knockbackZ, 0.0F, 1.0F, 0.0F);
    }

    public SpawnExplosionMessage(double x, double y, double z, float power, boolean isPlume,
                                 float knockbackX, float knockbackY, float knockbackZ,
                                 float axisX, float axisY, float axisZ) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.power = power;
        this.isPlume = isPlume;
        this.knockbackX = knockbackX;
        this.knockbackY = knockbackY;
        this.knockbackZ = knockbackZ;
        this.axisX = axisX;
        this.axisY = axisY;
        this.axisZ = axisZ;
    }

    public SpawnExplosionMessage(class_2540 buf) {
        this.x = buf.readDouble();
        this.y = buf.readDouble();
        this.z = buf.readDouble();
        this.power = buf.readFloat();
        this.isPlume = buf.readBoolean();
        this.knockbackX = buf.readFloat();
        this.knockbackY = buf.readFloat();
        this.knockbackZ = buf.readFloat();
        this.axisX = buf.readFloat();
        this.axisY = buf.readFloat();
        this.axisZ = buf.readFloat();
    }

    public void toBytes(class_2540 buf) {
        buf.writeDouble(this.x);
        buf.writeDouble(this.y);
        buf.writeDouble(this.z);
        buf.writeFloat(this.power);
        buf.writeBoolean(this.isPlume);
        buf.writeFloat(this.knockbackX);
        buf.writeFloat(this.knockbackY);
        buf.writeFloat(this.knockbackZ);
        buf.writeFloat(this.axisX);
        buf.writeFloat(this.axisY);
        buf.writeFloat(this.axisZ);
    }

    public double x() { return this.x; }
    public double y() { return this.y; }
    public double z() { return this.z; }
    public float power() { return this.power; }
    public boolean isPlume() { return this.isPlume; }
    public float knockbackX() { return this.knockbackX; }
    public float knockbackY() { return this.knockbackY; }
    public float knockbackZ() { return this.knockbackZ; }
    public float axisX() { return this.axisX; }
    public float axisY() { return this.axisY; }
    public float axisZ() { return this.axisZ; }
}
