package asd.itamio.createtnt;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Networking for the mod (Fabric). Carries the one packet that tells clients
 * where to render the explosion particles (and their knockback).
 */
public class ModNetwork {

    /** The explosion-effects channel id. */
    public static final class_2960 EXPLOSION_CHANNEL =
        new class_2960(BetterTNTs.MOD_ID, "spawn_explosion");

    /** Sends the explosion packet to a client. */
    public static void sendExplosion(class_3222 player, SpawnExplosionMessage msg) {
        class_2540 buf = PacketByteBufs.create();
        msg.toBytes(buf);
        ServerPlayNetworking.send(player, EXPLOSION_CHANNEL, buf);
    }
}
