package asd.itamio.createtnt;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2540;

/** Particle options for the blast wave (shake + delayed boom): power only. */
public record BlastWaveOption(float power) implements class_2394 {

    public static final class_2394.class_2395<BlastWaveOption> DESERIALIZER =
        new class_2394.class_2395<>() {
            @Override
            public BlastWaveOption method_10296(class_2396<BlastWaveOption> type, StringReader reader)
                throws CommandSyntaxException {
                reader.expect(' ');
                return new BlastWaveOption(reader.readFloat());
            }

            @Override
            public BlastWaveOption method_10297(class_2396<BlastWaveOption> type, class_2540 buf) {
                return new BlastWaveOption(buf.readFloat());
            }
        };

    @Override
    public void method_10294(class_2540 buf) {
        buf.writeFloat(this.power);
    }

    @Override
    public String method_10293() {
        return String.valueOf(this.power);
    }

    @Override
    public class_2396<?> method_10295() {
        return BetterTNTs.SHELL_BLAST_WAVE;
    }
}
