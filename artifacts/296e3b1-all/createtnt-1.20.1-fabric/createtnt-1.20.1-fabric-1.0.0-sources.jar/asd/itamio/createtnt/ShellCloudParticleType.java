package asd.itamio.createtnt;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2396;

/** ParticleType carrying {@link ShellCloudOption} (scale + plume flag). */
public class ShellCloudParticleType extends class_2396<ShellCloudOption> {

    public ShellCloudParticleType() {
        super(false, ShellCloudOption.DESERIALIZER);
    }

    @Override
    public Codec<ShellCloudOption> method_29138() {
        return RecordCodecBuilder.create(i -> i.group(
            Codec.FLOAT.fieldOf("scale").forGetter(ShellCloudOption::scale),
            Codec.BOOL.fieldOf("isPlume").forGetter(ShellCloudOption::isPlume),
            Codec.FLOAT.fieldOf("axisX").forGetter(ShellCloudOption::axisX),
            Codec.FLOAT.fieldOf("axisY").forGetter(ShellCloudOption::axisY),
            Codec.FLOAT.fieldOf("axisZ").forGetter(ShellCloudOption::axisZ))
            .apply(i, ShellCloudOption::new));
    }
}
