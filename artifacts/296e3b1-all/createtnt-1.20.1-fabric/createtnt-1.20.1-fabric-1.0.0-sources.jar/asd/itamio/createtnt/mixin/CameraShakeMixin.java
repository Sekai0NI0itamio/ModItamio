package asd.itamio.createtnt.mixin;

import asd.itamio.createtnt.CameraShakeHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies the camera shake to the camera's yaw/pitch angles at the end of
 * {@code Camera.setup}. 1.20.1's GameRenderer consumes the camera angles
 * (Axis.XP/YP rotations), NOT the rotation quaternion, so the quaternion can
 * not be used here. Roll is not rendered by the vanilla 1.20.1 view at all.
 */
@Mixin(class_4184.class)
public abstract class CameraShakeMixin {

    @Invoker("setRotation")
    protected abstract void createtnt$invokeSetRotation(float yaw, float pitch);

    @Inject(method = "setup", at = @At("TAIL"))
    private void createtnt$shakeCamera(class_1922 level, class_1297 entity, boolean thirdPerson,
                                       boolean inverse, float partialTicks, CallbackInfo ci) {
        class_243 disp = CameraShakeHandler.getDisplacementFor(partialTicks);
        if (disp.method_1027() < 1.0E-6D) {
            return;
        }
        class_4184 self = (class_4184) (Object) this;
        float yaw = self.method_19330() + (float) disp.field_1352;
        float pitch = class_3532.method_15363(self.method_19329() + (float) disp.field_1351, -90.0F, 90.0F);
        this.createtnt$invokeSetRotation(yaw, pitch);
    }
}
