package asd.itamio.createtnt.mixin;

import asd.itamio.createtnt.EnhancedExplosion;
import asd.itamio.createtnt.ModConfig;
import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1541;
import net.minecraft.class_1548;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import net.minecraft.class_5362;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Replaces vanilla explosions that originate from a primed TNT with our
 * {@link EnhancedExplosion}. Fabric has no explosion event, so we hook the
 * server-side explode entry point directly.
 */
@Mixin(class_3218.class)
public class ExplosionMixin {

    @Inject(method = "explode", at = @At("HEAD"), cancellable = true)
    private void createtnt$explode(class_1297 entity, class_1282 damageSource,
                                   class_5362 calculator,
                                   double x, double y, double z, float radius, boolean causesFire,
                                   class_1937.class_7867 interaction,
                                   CallbackInfoReturnable<class_1927> cir) {
        class_3218 level = (class_3218) (Object) this;

        if (ModConfig.enhancedCreeperExplosions && entity instanceof class_1548) {
            float powerMult = 1.0F + level.method_8409().method_43057() * 2.0F;
            float blockPower = ModConfig.blockPower * powerMult;
            float entityPower = ModConfig.entityPower * powerMult;
            float particlePower = ModConfig.tntStrength * (1.0F + (powerMult - 1.0F) * 0.25F);
            EnhancedExplosion enhancedExplosion = new EnhancedExplosion(level, entity, x, y, z,
                blockPower, entityPower, false, true, particlePower);
            enhancedExplosion.method_8348();
            enhancedExplosion.method_8350(true);
            float chainRadius = Math.max(blockPower, entityPower) * 2.0F + 4.0F;
            List<class_1541> chained = level.method_18467(class_1541.class,
                new class_238(x - chainRadius, y - chainRadius, z - chainRadius,
                    x + chainRadius, y + chainRadius, z + chainRadius));
            for (class_1541 tnt : chained) tnt.method_6967(0);
            cir.setReturnValue(enhancedExplosion);
            cir.cancel();
            return;
        }

        // Find a primed TNT at the explosion point.
        List<class_1541> tnts = level.method_18467(class_1541.class,
            new class_238(x - 1.0D, y - 1.0D, z - 1.0D, x + 1.0D, y + 1.0D, z + 1.0D));
        if (tnts.isEmpty()) {
            return;
        }

        // Run the enhanced explosion instead of the vanilla one.
        float powerMult = 1.0F + level.method_8409().method_43057() * 2.0F;
        float blockPower = ModConfig.blockPower * powerMult;
        float entityPower = ModConfig.entityPower * powerMult;
        float particlePower = ModConfig.tntStrength * (1.0F + (powerMult - 1.0F) * 0.25F);

        EnhancedExplosion enhancedExplosion = new EnhancedExplosion(level, tnts.get(0), x, y, z,
            blockPower, entityPower, false, true, particlePower);
        enhancedExplosion.method_8348();
        enhancedExplosion.method_8350(true);

        // Chain reaction: instantly detonate every primed TNT caught in the blast.
        float chainRadius = Math.max(blockPower, entityPower) * 2.0F + 4.0F;
        List<class_1541> chained = level.method_18467(class_1541.class,
            new class_238(x - chainRadius, y - chainRadius, z - chainRadius,
                x + chainRadius, y + chainRadius, z + chainRadius));
        for (class_1541 tnt : chained) {
            tnt.method_6967(0);
        }

        // Return the already-run explosion so callers get a valid object;
        // vanilla packets/particles are fully replaced by our own packet.
        cir.setReturnValue(enhancedExplosion);
        cir.cancel();
    }
}
