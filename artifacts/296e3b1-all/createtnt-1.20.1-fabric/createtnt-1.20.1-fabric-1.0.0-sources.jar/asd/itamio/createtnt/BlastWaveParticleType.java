package asd.itamio.createtnt;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2396;

/** ParticleType carrying {@link BlastWaveOption} (power). */
public class BlastWaveParticleType extends class_2396<BlastWaveOption> {

    public BlastWaveParticleType() {
        super(false, BlastWaveOption.DESERIALIZER);
    }

    @Override
    public Codec<BlastWaveOption> method_29138() {
        return RecordCodecBuilder.create(i -> i.group(
            Codec.FLOAT.fieldOf("power").forGetter(BlastWaveOption::power))
            .apply(i, BlastWaveOption::new));
    }
}
