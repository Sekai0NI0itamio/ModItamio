package asd.itamio.createtnt;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;

/**
 * Client-side entry point for the explosion visuals.
 *
 * <p>Every explosion spawns exactly two controller particles:</p>
 * <ol>
 *   <li>a {@link BlastWaveEffectParticle} — an invisible expanding wavefront
 *       that triggers the screen shake and plays the delayed boom when it
 *       reaches the player, and</li>
 *   <li>a {@link ShellExplosionCloudParticle} — the big smoke plume with its
 *       blast-ray streaks, gated by the {@code showShellExplosionClouds}
 *       config.</li>
 * </ol>
 */
public final class ShellExplosionEffects {

    private ShellExplosionEffects() {
    }

    /** Packet handler: apply knockback to the local player, then spawn. */
    public static void handlePacket(double x, double y, double z, float power, boolean isPlume,
                                    float knockbackX, float knockbackY, float knockbackZ,
                                    float axisX, float axisY, float axisZ) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        class_243 knock = new class_243(knockbackX, knockbackY, knockbackZ);
        mc.field_1724.method_18799(mc.field_1724.method_18798().method_1019(knock));
        spawnShellExplosion(mc.field_1687, x, y, z, power, isPlume, axisX, axisY, axisZ);
    }

    public static void spawnShellExplosion(class_638 level, double x, double y, double z,
                                           float power, boolean isPlume,
                                           float axisX, float axisY, float axisZ) {
        // Scale the ENTIRE effect bundle (smoke cloud size/spread, blast-ray
        // size, blast-wave shake radius/strength, sound volume) with the
        // configured visual scale.
        power *= ModConfig.explosionVisualScale;

        level.method_8466(new BlastWaveOption(power), true, x, y, z, 0.0D, 0.0D, 0.0D);

        if (ModConfig.showShellExplosionClouds) {
            level.method_8466(new ShellCloudOption(power, isPlume, axisX, axisY, axisZ), true,
                x, y, z, 0.0D, 0.0D, 0.0D);
        }
    }
}
