package asd.itamio.createtnt;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2396;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** ParticleType carrying {@link BlastWaveOption} (power). */
public class BlastWaveParticleType extends class_2396<BlastWaveOption> {

    private static final MapCodec<BlastWaveOption> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
        Codec.FLOAT.fieldOf("power").forGetter(BlastWaveOption::power))
        .apply(i, BlastWaveOption::new));

    private static final class_9139<class_9129, BlastWaveOption> STREAM_CODEC =
        class_9139.method_56437(
            (buf, o) -> buf.method_52941(o.power()),
            buf -> new BlastWaveOption(buf.readFloat()));

    public BlastWaveParticleType() {
        super(false);
    }

    @Override
    public MapCodec<BlastWaveOption> method_29138() {
        return CODEC;
    }

    @Override
    public class_9139<? super class_9129, BlastWaveOption> method_56179() {
        return STREAM_CODEC;
    }
}
