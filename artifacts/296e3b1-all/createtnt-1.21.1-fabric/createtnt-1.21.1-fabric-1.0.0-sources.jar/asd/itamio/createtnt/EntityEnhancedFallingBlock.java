package asd.itamio.createtnt;

import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1540;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2680;
import net.minecraft.class_3231;
import net.minecraft.class_3486;
import net.minecraft.class_8923;

/**
 * Enhanced falling block entity with realistic impact physics.
 *
 * <p>Features beyond vanilla {@link class_1540}:</p>
 * <ul>
 *   <li>Breaks glass blocks on impact and continues falling through</li>
 *   <li>Breaks leaves on impact and continues falling through</li>
 *   <li>Damage to entities scales with accumulated fall speed</li>
 *   <li>Fluid source blocks (water/lava) are placed on landing so they flow again</li>
 *   <li>The block state rides along the vanilla spawn packet (the extra data
 *       int), so the client renders the correct block from the first frame.</li>
 * </ul>
 */
public class EntityEnhancedFallingBlock extends class_1540 {

    /** Tracks the maximum downward speed reached during the fall. */
    private float maxFallSpeed = 0.0F;

    /** Stuck detection: ticks spent effectively motionless without onGround
     *  (wedged inside a wall or balanced on another entity). After a few
     *  such ticks the block force-settles instead of glitching forever. */
    private int stuckTicks;
    private double lastSettleX;
    private double lastSettleY;
    private double lastSettleZ;

    /**
     * Server-side copy of the block state. The parent's private
     * {@code blockState} field is only set through its private constructor or
     * the client spawn packet, so we keep our own copy and return it from
     * {@link #method_6962()} whenever it's set.
     */
    private class_2680 syncedState;

    public EntityEnhancedFallingBlock(class_1299<? extends class_1540> type, class_1937 level) {
        super(type, level);
    }

    public EntityEnhancedFallingBlock(class_1937 level, double x, double y, double z, class_2680 state) {
        this(BetterTNTs.ENHANCED_FALLING_BLOCK, level);
        this.syncedState = state;
        this.method_5814(x, y, z);
        this.field_6014 = x;
        this.field_6036 = y;
        this.field_5969 = z;
        this.method_6963(this.method_24515());
        this.field_7192 = 0;
    }

    @Override
    public void method_5773() {
        class_2680 fallTile = this.method_6962();
        if (fallTile == null || fallTile.method_26215()) {
            this.method_31472();
            return;
        }

        class_2248 block = fallTile.method_26204();

        this.field_6014 = this.method_23317();
        this.field_6036 = this.method_23318();
        this.field_5969 = this.method_23321();

        if (this.field_7192++ == 0) {
            class_2338 blockpos = this.method_24515();
            if (this.method_37908().method_8320(blockpos).method_26204() == block) {
                this.method_37908().method_8652(blockpos, class_2246.field_10124.method_9564(), 3);
            }
            // Note: do NOT kill the entity if the block is already gone.
            // The explosion may have already set the block to air before
            // spawning this entity, which is a valid state.
        }

        if (!this.method_5740()) {
            this.method_18799(this.method_18798().method_1031(0.0D, -ModConfig.fallingBlockGravity, 0.0D));
        }

        // Track maximum fall speed for damage scaling.
        double currentSpeed = Math.abs(this.method_18798().field_1351);
        if (currentSpeed > this.maxFallSpeed) {
            this.maxFallSpeed = (float) currentSpeed;
        }

        // --- Horizontal energy decay (boom then slow down) ---
        // No hard cap on initial launch — let the explosion's boom fling
        // blocks outward at full force. Then apply a linear decay to the
        // horizontal speed vector so blocks rapidly lose energy and settle.
        double hSpeed = Math.sqrt(this.method_18798().field_1352 * this.method_18798().field_1352
            + this.method_18798().field_1350 * this.method_18798().field_1350);
        if (hSpeed > 0.0D) {
            double decay = ModConfig.fallingBlockHorizontalDecay;
            double newSpeed = Math.max(0.0D, hSpeed - decay);
            double decayScale = newSpeed / hSpeed;
            this.method_18799(new Vec3dHelper(this.method_18798()).scaleXZ(decayScale));
        }

        this.method_5784(class_1313.field_6308, this.method_18798());

        // --- Debris smoke trail ---
        // Spawn a small smoke puff every few ticks while the block is flying.
        if (!this.method_37908().field_9236 && this.field_7192 > 1 && this.field_7192 % 3 == 0) {
            double speed = this.method_18798().method_1033();
            if (speed > 0.1D && this.method_37908() instanceof net.minecraft.class_3218 serverLevel) {
                serverLevel.method_14199(net.minecraft.class_2398.field_11237,
                    this.method_23317(), this.method_23318(), this.method_23321(), 1, 0.0D, 0.02D, 0.0D, 0.0D);
            }
        }

        if (!this.method_37908().field_9236) {
            class_2338 blockpos1 = this.method_24515();

            if (!this.method_24828()) {
                if (this.field_7192 > 100 && (blockpos1.method_10264() < this.method_37908().method_31607()
                    || blockpos1.method_10264() > this.method_37908().method_31600())) {
                    // Fell out of the world — lost to the void.
                    this.method_31472();
                    return;
                }
                if (this.field_7192 > ModConfig.fallingBlockMaxLifetime) {
                    // Lifetime expired: settle where it is instead of vanishing.
                    this.method_31472();
                    this.settleBlock(this.method_24515());
                    return;
                }

                // --- Stuck detection ---
                // A falling block wedged inside a wall or resting on another
                // falling block entity never gets onGround (entities don't
                // collide with blocks when fully embedded). If it has been
                // effectively motionless for several ticks, force-settle it.
                double movedSq = (this.method_23317() - this.lastSettleX) * (this.method_23317() - this.lastSettleX)
                    + (this.method_23318() - this.lastSettleY) * (this.method_23318() - this.lastSettleY)
                    + (this.method_23321() - this.lastSettleZ) * (this.method_23321() - this.lastSettleZ);
                double speedSq = this.method_18798().method_1027();
                if (movedSq < 1.0E-6D && speedSq < 1.0E-4D) {
                    this.stuckTicks++;
                } else {
                    this.stuckTicks = 0;
                }
                this.lastSettleX = this.method_23317();
                this.lastSettleY = this.method_23318();
                this.lastSettleZ = this.method_23321();
                if (this.stuckTicks >= 10) {
                    this.method_31472();
                    this.settleBlock(this.method_24515());
                    return;
                }
            } else {
                // Check the block the entity is landing on (just below).
                class_2338 belowPos = class_2338.method_49637(
                    this.method_23317(), this.method_23318() - 0.01D, this.method_23321());
                class_2680 belowState = this.method_37908().method_8320(belowPos);
                class_2248 belowBlock = belowState.method_26204();

                // --- Break-through logic ---
                // Glass: shatter on impact, continue falling.
                // Leaves: disintegrate, continue falling (no item drop).
                boolean breakThrough = false;
                if (belowBlock instanceof class_8923
                    || belowBlock instanceof net.minecraft.class_2504
                    || belowBlock == class_2246.field_10285) {
                    // No item drop — glass shatters into nothing.
                    this.method_37908().method_8652(belowPos, class_2246.field_10124.method_9564(), 3);
                    this.method_37908().method_20290(2001, belowPos, class_2248.method_9507(belowState));
                    breakThrough = true;
                } else if (belowBlock instanceof net.minecraft.class_2397) {
                    this.method_37908().method_8652(belowPos, class_2246.field_10124.method_9564(), 3);
                    breakThrough = true;
                }

                if (breakThrough) {
                    // Keep falling through the broken block.
                    this.method_24830(false);
                    // Reduce speed from the impact but preserve momentum.
                    this.method_18799(new Vec3dHelper(this.method_18798()).scaleImpact(0.85D, 0.6D, 0.85D));
                } else {
                    // --- Normal landing ---
                    this.method_18799(new Vec3dHelper(this.method_18798()).scaleImpact(0.7D, -0.5D, 0.7D));

                    // Deal speed-scaled damage to entities in the landing zone.
                    dealImpactDamage();

                    if (belowBlock != class_2246.field_10008) {
                        this.method_31472();
                        this.settleBlock(blockpos1);
                    }
                }
            }
        }

        this.method_18799(this.method_18798().method_1021(0.98D));
    }

    /** Tiny helper for scaling delta movement components. */
    private static final class Vec3dHelper {
        private final double x, y, z;
        Vec3dHelper(net.minecraft.class_243 v) { this.x = v.field_1352; this.y = v.field_1351; this.z = v.field_1350; }
        net.minecraft.class_243 scaleXZ(double scale) {
            return new net.minecraft.class_243(this.x * scale, this.y, this.z * scale);
        }
        net.minecraft.class_243 scaleImpact(double sx, double sy, double sz) {
            return new net.minecraft.class_243(this.x * sx, this.y * sy, this.z * sz);
        }
    }

    /**
     * Converts this falling entity back into a placed block. Searches upward
     * from the entity's position for the first free spot (air, liquid, or a
     * replaceable block like grass/snow) with solid footing below it, and
     * places the block there. This handles the cases where the entity's own
     * position is not placeable: embedded in terrain by float error, stacked
     * on another just-placed debris block, or wedged inside a wall.
     *
     * <p>If no valid spot exists (void, ceiling of bedrock...), solid blocks
     * drop as an item instead of vanishing; fluids simply evaporate.</p>
     */
    private void settleBlock(class_2338 startPos) {
        class_2680 fallTile = this.method_6962();
        if (fallTile == null || fallTile.method_26215()) {
            return;
        }
        class_2248 block = fallTile.method_26204();
        boolean isFluid = fallTile.method_26227().method_15767(class_3486.field_15517)
            || fallTile.method_26227().method_15767(class_3486.field_15518);

        for (int i = 0; i < 5; i++) {
            class_2338 tryPos = startPos.method_10086(i);
            if (tryPos.method_10264() > this.method_37908().method_31600() - 1) {
                break;
            }
            class_2680 at = this.method_37908().method_8320(tryPos);
            boolean free = at.method_26215()
                || !at.method_26227().method_15769()
                || at.method_45474();
            if (!free) {
                continue;
            }
            // Solid blocks placed in air need solid footing below (not
            // air/liquid/torch...). When displacing a liquid, lodged debris
            // is fine anywhere.
            boolean displacingLiquid = !at.method_26227().method_15769();
            if (!isFluid && !displacingLiquid
                && class_2346.method_10128(this.method_37908().method_8320(tryPos.method_10074()))) {
                continue;
            }

            // Fluid source blocks (Blocks.WATER / Blocks.LAVA) flow naturally
            // when placed — their LEVEL property defaults to 0.
            class_2680 placeState = fallTile;
            this.method_37908().method_8652(tryPos, placeState, 3);
            // Grant the settled block a grace period so the collapse cascade
            // doesn't immediately re-fall it (which would loop forever when
            // an unsupported block lands on a static block right below it).
            BlockCollapseHandler.markSettled(this.method_37908(), tryPos);
            return;
        }

        // Nowhere to settle: drop the block as an item rather than deleting
        // it (fluids have no item form and simply evaporate).
        if (!isFluid) {
            class_1792 item = class_1792.method_7867(block);
            if (item != class_1802.field_8162) {
                this.method_5775(new class_1799(item));
            }
        }
    }

    /**
     * Deals damage to entities in the landing zone, scaled by accumulated fall
     * speed. Higher speed = more damage. Damage cap is configurable.
     */
    private void dealImpactDamage() {
        if (this.maxFallSpeed < 0.3D) return;

        float damage = this.maxFallSpeed * ModConfig.fallingBlockImpactDamageMultiplier;
        damage = Math.min(damage, ModConfig.fallingBlockImpactDamageCap);

        List<class_1297> list = this.method_37908().method_8335(this, this.method_5829());
        class_1282 source = this.method_37908().method_48963().method_48798(this);

        for (class_1297 entity : list) {
            entity.method_5643(source, damage);
        }
    }

    /**
     * Returns the block state this falling entity represents. On the server
     * our own field is set by the constructor; on the client the parent's
     * field is populated from the spawn packet — fall back to it.
     */
    @Override
    public class_2680 method_6962() {
        if (this.syncedState != null) {
            return this.syncedState;
        }
        return super.method_6962();
    }

    /** Sends the block state id in the vanilla spawn packet's extra data. */
    @Override
    public class_2596<class_2602> method_18002(class_3231 serverEntity) {
        return new class_2604(this, serverEntity, class_2248.method_9507(this.method_6962()));
    }

    @Override
    protected void method_5652(class_2487 tag) {
        super.method_5652(tag);
        tag.method_10569("EnhancedState", class_2248.method_9507(this.method_6962()));
    }

    @Override
    protected void method_5749(class_2487 tag) {
        super.method_5749(tag);
        if (tag.method_10545("EnhancedState")) {
            this.syncedState = class_2248.method_9531(tag.method_10550("EnhancedState"));
        }
    }
}
