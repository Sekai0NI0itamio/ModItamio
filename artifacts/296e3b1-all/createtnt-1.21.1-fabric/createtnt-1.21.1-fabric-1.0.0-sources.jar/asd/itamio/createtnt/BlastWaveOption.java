package asd.itamio.createtnt;

import net.minecraft.class_2394;
import net.minecraft.class_2396;

/** Particle options for the blast wave (shake + delayed boom): power only. */
public record BlastWaveOption(float power) implements class_2394 {
    @Override
    public class_2396<?> method_10295() {
        return BetterTNTs.SHELL_BLAST_WAVE;
    }
}
