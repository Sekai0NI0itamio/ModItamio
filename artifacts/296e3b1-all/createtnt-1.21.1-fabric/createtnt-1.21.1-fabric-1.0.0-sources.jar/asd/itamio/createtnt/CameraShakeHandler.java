package asd.itamio.createtnt;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;
import net.minecraft.class_243;
import net.minecraft.class_310;

/**
 * Camera shake: a spring–damper oscillator per rotational axis
 * (yaw/pitch/roll). A blast kicks the velocity with a randomized impulse; the
 * spring oscillates and settles. The camera offset is sampled per frame in
 * The camera offset is sampled per frame by the Camera mixin with
 * partial-tick interpolation.
 *
 * <ul>
 *   <li>restitution = {@code shakeSpringiness} (0.08)</li>
 *   <li>drag = {@code shakeDecay} (0.3)</li>
 *   <li>magnitudes scaled by {@code shakeIntensity} (1.3)</li>
 *   <li>per-axis clamp {@code 45 * intensity} degrees</li>
 * </ul>
 */
public class CameraShakeHandler {

    private static final Random RANDOM = new Random();

    /** One queued shake impulse (magnitudes + blast position). */
    private static final class ScreenShakeEffect {
        int duration;
        final float yawMagnitude;
        final float pitchMagnitude;
        final float rollMagnitude;
        final double posX;
        final double posY;
        final double posZ;

        ScreenShakeEffect(int duration, float yawMagnitude, float pitchMagnitude, float rollMagnitude,
                          double posX, double posY, double posZ) {
            this.duration = duration;
            this.yawMagnitude = yawMagnitude;
            this.pitchMagnitude = pitchMagnitude;
            this.rollMagnitude = rollMagnitude;
            this.posX = posX;
            this.posY = posY;
            this.posZ = posZ;
        }

        /** Counts down; returns true when the shake should fire now. */
        boolean tick() {
            return --this.duration <= 0;
        }
    }

    private static final Set<ScreenShakeEffect> delayedShakes = new LinkedHashSet<>();
    private static class_243 velocity = class_243.field_1353;
    private static class_243 acceleration = class_243.field_1353;
    private static class_243 displacement = class_243.field_1353;

    /**
     * Immediate shake from the blast wave (duration 0 = applied at once).
     */
    public static void addShakeEffect(float yawMagnitude, float pitchMagnitude, float rollMagnitude,
                                      double posX, double posY, double posZ) {
        addEffect(new ScreenShakeEffect(0, yawMagnitude, pitchMagnitude, rollMagnitude, posX, posY, posZ));
    }

    /**
     * Adds a shake; a duration of -1 delays the shake by the blast wave's
     * travel time to the player.
     */
    public static void addEffect(ScreenShakeEffect effect) {
        if (!ModConfig.screenShake) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (effect.duration == -1) {
            int ticks = 0;
            if (ModConfig.blastEffectDelaySpeed >= 1e-2F && mc.field_1724 != null) {
                double distSqr = mc.field_1724.method_5649(effect.posX, effect.posY, effect.posZ);
                double timeInSec = Math.sqrt(distSqr) / (double) ModConfig.blastEffectDelaySpeed;
                ticks = (int) Math.floor(timeInSec * 20.0D);
            }
            effect = new ScreenShakeEffect(ticks, effect.yawMagnitude, effect.pitchMagnitude,
                effect.rollMagnitude, effect.posX, effect.posY, effect.posZ);
        }
        if (effect.duration <= 0) {
            immediatelyAddEffect(effect);
        } else {
            delayedShakes.add(effect);
        }
    }

    /** Kicks the spring velocity with a randomized impulse. */
    private static void immediatelyAddEffect(ScreenShakeEffect effect) {
        // Scale magnitudes by the configured shake intensity.
        float shakeScale = ModConfig.shakeIntensity;
        float yaw = effect.yawMagnitude * shakeScale;
        float pitch = effect.pitchMagnitude * shakeScale;
        float roll = effect.rollMagnitude * shakeScale;
        double dy = yaw * (RANDOM.nextDouble() - RANDOM.nextDouble()) * 0.5D;
        double dp = pitch * (RANDOM.nextDouble() - RANDOM.nextDouble()) * 0.5D;
        double dr = roll * (RANDOM.nextDouble() - RANDOM.nextDouble()) * 0.5D;
        velocity = velocity.method_1031(dy, dp, dr);
    }

    /** Releases delayed shakes, then integrates the spring. Called from
     *  the Fabric client-tick callback (end of tick). */
    public void onClientTick() {
        for (Iterator<ScreenShakeEffect> iter = delayedShakes.iterator(); iter.hasNext(); ) {
            ScreenShakeEffect effect = iter.next();
            if (effect.tick()) {
                immediatelyAddEffect(effect);
                iter.remove();
            }
        }
        int iterations = 10;
        double dt = 1.0D / iterations;
        double restitution = Math.max(0.005D, ModConfig.shakeSpringiness);
        double drag = Math.max(0.005D, ModConfig.shakeDecay);

        for (int i = 0; i < iterations; ++i) {
            class_243 newRotationDisplacement = displacement
                .method_1019(velocity.method_1021(dt))
                .method_1019(acceleration.method_1021(0.5D * dt * dt));
            class_243 newAccel = displacement.method_1021(-restitution)
                .method_1019(velocity.method_1021(-drag));
            class_243 newVel = velocity
                .method_1019(acceleration.method_1019(newAccel).method_1021(0.5D * dt));
            displacement = newRotationDisplacement;
            velocity = newVel;
            acceleration = newAccel;
            applyConstraints();
        }
        if (displacement.method_1027() < 1e-4D
            && velocity.method_1027() < 1e-4D
            && acceleration.method_1027() < 1e-4D) {
            clearEffects();
        }
    }

    /** Resets the spring to rest. */
    private static void clearEffects() {
        displacement = class_243.field_1353;
        velocity = class_243.field_1353;
        acceleration = class_243.field_1353;
    }

    /** Clamps each axis to 45 * intensity degrees. */
    private static void applyConstraints() {
        double maxRotation = 45.0D * ModConfig.shakeIntensity;
        if (Math.abs(displacement.field_1352) > maxRotation) {
            displacement = new class_243(Math.copySign(maxRotation, displacement.field_1352), displacement.field_1351, displacement.field_1350);
            velocity = new class_243(0.0D, velocity.field_1351, velocity.field_1350);
        }
        if (Math.abs(displacement.field_1351) > maxRotation) {
            displacement = new class_243(displacement.field_1352, Math.copySign(maxRotation, displacement.field_1351), displacement.field_1350);
            velocity = new class_243(velocity.field_1352, 0.0D, velocity.field_1350);
        }
        if (Math.abs(displacement.field_1350) > maxRotation) {
            displacement = new class_243(displacement.field_1352, displacement.field_1351, Math.copySign(maxRotation, displacement.field_1350));
            velocity = new class_243(velocity.field_1352, velocity.field_1351, 0.0D);
        }
    }

    /** Samples the spring with partial-tick interpolation (for the camera
     *  mixin in the Fabric build). */
    public static class_243 getDisplacementFor(float partialTicks) {
        return displacement
            .method_1019(velocity.method_1021(partialTicks))
            .method_1019(acceleration.method_1021(partialTicks * partialTicks * 0.5D));
    }
}
