package asd.itamio.createtnt;

import net.minecraft.class_1109;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import net.minecraft.class_3998;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

/**
 * An invisible particle representing a blast wavefront expanding outward from
 * the explosion at {@code blastEffectDelaySpeed} (default 320 m/s).
 *
 * <p>When the front reaches the local player it applies the screen shake (with
 * quadratic falloff inside {@code blastRadius}) and plays the explosion sound
 * if the player is within {@code volume * 16} blocks — producing the
 * "see the flash, then the boom arrives" delay of a distant blast.</p>
 *
 * <p>Parameters: blast radius is {@code power * 12}, sound volume is
 * {@code max(power * 2, 16)}, pitch is {@code 0.8 + rand * 0.4}, and the shake
 * strength is {@code power * shakePowerMultiplier} clamped to
 * {@code shakePowerLimit} degrees.</p>
 */
public class BlastWaveEffectParticle extends class_3998 {

    private final double blastRadius;
    private final float volume;
    private final float pitch;
    private final float shakePower;
    private final float shakeLimit;

    private final double functionalRadius;
    private double currentRadius;

    BlastWaveEffectParticle(class_638 level, double x, double y, double z, float power) {
        super(level, x, y, z);
        this.blastRadius = (double) power * 12.0D;
        this.volume = Math.max(power * 2.0F, 16.0F);
        this.pitch = 0.8F + this.field_3840.method_43057() * 0.4F;
        this.shakePower = power * ModConfig.shakePowerMultiplier;
        this.shakeLimit = ModConfig.shakePowerLimit;

        this.functionalRadius = Math.max(this.blastRadius, (double) this.volume * 16.0D);
        this.currentRadius = 0.0D;

        this.field_3852 = 0.0D;
        this.field_3869 = 0.0D;
        this.field_3850 = 0.0D;
        this.field_3844 = 0.0F;
        this.field_3862 = false;
        // 100-tick timeout so the wave can't linger forever.
        this.field_3847 = 100;
    }

    @Override
    public void method_3070() {
        class_1657 player = class_310.method_1551().field_1724;
        if (player == null) {
            this.method_3085();
            return;
        }

        // Near-zero delay speed means the effect is instantaneous.
        boolean instant = ModConfig.blastEffectDelaySpeed < 1e-2F;
        if (instant) {
            this.currentRadius = 0.0D;
        }
        double speed = ModConfig.blastEffectDelaySpeed * 0.05D;
        double newRadius = instant ? this.functionalRadius
            : Math.min(this.currentRadius + speed, this.functionalRadius);

        double dist = Math.sqrt(player.method_5649(this.field_3874, this.field_3854, this.field_3871));
        if (this.currentRadius <= dist && dist <= newRadius) {
            // The wavefront has arrived at the player this tick.
            if (dist < this.blastRadius && this.blastRadius > 0.1D) {
                float f = 1.0F - (float) (dist / this.blastRadius);
                float f2 = f * f;
                float shake = Math.min(this.shakeLimit, this.shakePower * f2);
                // Duration 0 = the shake is applied immediately on arrival.
                CameraShakeHandler.addShakeEffect(shake, shake * 0.5F, shake * 0.5F,
                    this.field_3874, this.field_3854, this.field_3871);
            }
            double volumeDist = (double) this.volume * 16.0D;
            if (dist < volumeDist) {
                class_310.method_1551().method_1483().method_4873(new class_1109(
                    BetterTNTs.EXPLOSION_BOOM, class_3419.field_15245,
                    this.volume, this.pitch,
                    class_5819.method_43049(this.field_3851.field_9229.method_43055()),
                    this.field_3874, this.field_3854, this.field_3871));
            }
            this.method_3085();
            return;
        }

        if (instant || newRadius >= this.functionalRadius) {
            this.method_3085();
            return;
        }
        this.currentRadius = newRadius;
        // Only reached while the wave is still expanding, so the 100-tick
        // timeout only counts expansion time.
        super.method_3070();
    }

    /** Provider creating the wave from its option data. */
    public static class Provider implements class_707<BlastWaveOption> {
        @Override
        public class_703 createParticle(BlastWaveOption data, class_638 level, double x, double y,
                                       double z, double xSpeed, double ySpeed, double zSpeed) {
            return new BlastWaveEffectParticle(level, x, y, z, data.power());
        }
    }
}
