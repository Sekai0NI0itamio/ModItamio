package asd.itamio.createtnt;

import net.minecraft.class_2394;
import net.minecraft.class_2396;

/** Particle options for the explosion cloud controller: scale, plume flag, plume axis. */
public record ShellCloudOption(float scale, boolean isPlume, float axisX, float axisY, float axisZ)
    implements class_2394 {
    @Override
    public class_2396<?> method_10295() {
        return BetterTNTs.SHELL_EXPLOSION_CLOUD;
    }
}
