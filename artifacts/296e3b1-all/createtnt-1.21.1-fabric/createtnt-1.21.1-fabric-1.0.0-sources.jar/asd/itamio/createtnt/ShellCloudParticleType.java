package asd.itamio.createtnt;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2396;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** ParticleType carrying {@link ShellCloudOption} (scale + plume flag). */
public class ShellCloudParticleType extends class_2396<ShellCloudOption> {

    private static final MapCodec<ShellCloudOption> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
        Codec.FLOAT.fieldOf("scale").forGetter(ShellCloudOption::scale),
        Codec.BOOL.fieldOf("isPlume").forGetter(ShellCloudOption::isPlume),
        Codec.FLOAT.fieldOf("axisX").forGetter(ShellCloudOption::axisX),
        Codec.FLOAT.fieldOf("axisY").forGetter(ShellCloudOption::axisY),
        Codec.FLOAT.fieldOf("axisZ").forGetter(ShellCloudOption::axisZ))
        .apply(i, ShellCloudOption::new));

    private static final class_9139<class_9129, ShellCloudOption> STREAM_CODEC =
        class_9139.method_56437(
            (buf, o) -> {
                buf.method_52941(o.scale());
                buf.method_52964(o.isPlume());
                buf.method_52941(o.axisX());
                buf.method_52941(o.axisY());
                buf.method_52941(o.axisZ());
            },
            buf -> new ShellCloudOption(buf.readFloat(), buf.readBoolean(),
                buf.readFloat(), buf.readFloat(), buf.readFloat()));

    public ShellCloudParticleType() {
        super(false);
    }

    @Override
    public MapCodec<ShellCloudOption> method_29138() {
        return CODEC;
    }

    @Override
    public class_9139<? super class_9129, ShellCloudOption> method_56179() {
        return STREAM_CODEC;
    }
}
