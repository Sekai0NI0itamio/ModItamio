package asd.itamio.createtnt;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2396;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** ParticleType carrying {@link ShellSmokeOption} (lifetime + scale + trail flag). */
public class ShellSmokeParticleType extends class_2396<ShellSmokeOption> {

    private static final MapCodec<ShellSmokeOption> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
        Codec.INT.fieldOf("lifetime").forGetter(ShellSmokeOption::lifetime),
        Codec.FLOAT.fieldOf("scale").forGetter(ShellSmokeOption::scale),
        Codec.BOOL.optionalFieldOf("trail", false).forGetter(ShellSmokeOption::trail))
        .apply(i, ShellSmokeOption::new));

    private static final class_9139<class_9129, ShellSmokeOption> STREAM_CODEC =
        class_9139.method_56437(
            (buf, o) -> {
                buf.method_10804(o.lifetime());
                buf.method_52941(o.scale());
                buf.method_52964(o.trail());
            },
            buf -> new ShellSmokeOption(buf.method_10816(), buf.readFloat(), buf.readBoolean()));

    public ShellSmokeParticleType() {
        super(false);
    }

    @Override
    public MapCodec<ShellSmokeOption> method_29138() {
        return CODEC;
    }

    @Override
    public class_9139<? super class_9129, ShellSmokeOption> method_56179() {
        return STREAM_CODEC;
    }
}
