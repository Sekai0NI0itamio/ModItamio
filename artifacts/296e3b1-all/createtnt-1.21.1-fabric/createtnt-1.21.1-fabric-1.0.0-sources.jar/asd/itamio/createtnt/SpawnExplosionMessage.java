package asd.itamio.createtnt;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Tells the client to render the explosion at a given position.
 *
 * <p>The payload carries the explosion {@code power} (particle sizing scale)
 * and the receiving player's knockback vector, which the client applies
 * directly to its own player entity (player motion is client-authoritative).</p>
 */
public record SpawnExplosionMessage(double x, double y, double z, float power, boolean isPlume,
                                    float knockbackX, float knockbackY, float knockbackZ,
                                    float axisX, float axisY, float axisZ)
    implements class_8710 {

    public static final class_8710.class_9154<SpawnExplosionMessage> TYPE =
        new class_8710.class_9154<>(class_2960.method_60655(BetterTNTs.MOD_ID, "spawn_explosion"));

    public static final class_9139<class_2540, SpawnExplosionMessage> STREAM_CODEC =
        new class_9139<>() {
            @Override
            public SpawnExplosionMessage decode(class_2540 buf) {
                return new SpawnExplosionMessage(
                    buf.readDouble(), buf.readDouble(), buf.readDouble(),
                    buf.readFloat(), buf.readBoolean(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat());
            }

            @Override
            public void encode(class_2540 buf, SpawnExplosionMessage msg) {
                buf.method_52940(msg.x);
                buf.method_52940(msg.y);
                buf.method_52940(msg.z);
                buf.method_52941(msg.power);
                buf.method_52964(msg.isPlume);
        buf.method_52941(msg.knockbackX);
        buf.method_52941(msg.knockbackY);
        buf.method_52941(msg.knockbackZ);
        buf.method_52941(msg.axisX);
        buf.method_52941(msg.axisY);
        buf.method_52941(msg.axisZ);
            }
        };

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
