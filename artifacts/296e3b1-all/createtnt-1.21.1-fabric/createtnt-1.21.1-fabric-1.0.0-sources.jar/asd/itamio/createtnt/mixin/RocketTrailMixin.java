package asd.itamio.createtnt.mixin;

import asd.itamio.createtnt.ModConfig;
import net.minecraft.class_1671;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Hides the vanilla white firework trail for shell rockets (crossbow/dispenser);
 * the mod spawns its own smoke. Elytra/hand rockets keep the vanilla trail.
 */
@Mixin(class_1671.class)
public class RocketTrailMixin {

    @Redirect(method = "tick", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/level/Level;addParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)V"))
    private void createtnt$suppressVanillaTrail(class_1937 level, class_2394 options,
                                                double x, double y, double z,
                                                double vx, double vy, double vz) {
        class_1671 self = (class_1671) (Object) this;
        if (ModConfig.rocketShellExplosions && self.method_7477()) {
            return;
        }
        level.method_8406(options, x, y, z, vx, vy, vz);
    }
}
