package asd.itamio.createtnt.mixin;

import asd.itamio.createtnt.CameraShakeHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies the camera shake to the camera's rotation quaternion at the end of
 * {@code Camera.setup}. Fabric has no viewport event, so we hook the camera
 * setup directly.
 */
@Mixin(class_4184.class)
public class CameraShakeMixin {

    @Inject(method = "setup", at = @At("TAIL"))
    private void createtnt$shakeCamera(class_1922 level, class_1297 entity, boolean thirdPerson,
                                       boolean inverse, float partialTicks, CallbackInfo ci) {
        class_4184 self = (class_4184) (Object) this;
        class_243 disp = CameraShakeHandler.getDisplacementFor(partialTicks);
        if (disp.method_1027() < 1.0E-6D) {
            return;
        }
        // Add the shake as a camera-space delta rotation on the live
        // quaternion (yaw = disp.x, pitch = disp.y, roll = disp.z).
        Quaternionf shake = new Quaternionf().rotationYXZ(
            (float) (disp.field_1352 * class_3532.field_29847),
            (float) (disp.field_1351 * class_3532.field_29847),
            (float) (disp.field_1350 * class_3532.field_29847));
        self.method_23767().mul(shake);
    }
}
