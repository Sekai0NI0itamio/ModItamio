package asd.itamio.createtnt.mixin;

import asd.itamio.createtnt.EntityEnhancedTNTPrimed;
import asd.itamio.createtnt.RocketTracker;
import net.minecraft.class_1297;
import net.minecraft.class_1541;
import net.minecraft.class_1671;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Replaces vanilla {@link class_1541} with {@link EntityEnhancedTNTPrimed}
 * when it spawns, so all TNT (flint &amp; steel, redstone, arrows, chains)
 * gets the water-aware fuse logic. Fabric has no entity-join event, so we
 * hook the spawn entry point.
 */
@Mixin(class_3218.class)
public class EntitySpawnMixin {

    @Inject(method = "addEntity", at = @At("HEAD"), cancellable = true)
    private void createtnt$replaceTnt(class_1297 entity, CallbackInfoReturnable<Boolean> cir) {
        class_3218 level = (class_3218) (Object) this;
        if (entity instanceof class_1671 rocket && rocket.method_7477()) {
            RocketTracker.track(level, rocket);
            return;
        }
        // Exact class match so we don't catch our own enhanced subclass.
        if (entity.getClass() != class_1541.class) {
            return;
        }
        class_1541 vanilla = (class_1541) entity;

        EntityEnhancedTNTPrimed enhanced = new EntityEnhancedTNTPrimed(
            level, vanilla.method_23317(), vanilla.method_23318(), vanilla.method_23321(), vanilla.method_6970());
        enhanced.method_6967(vanilla.method_6969());
        enhanced.method_18799(vanilla.method_18798());

        cir.setReturnValue(level.method_8649(enhanced));
        cir.cancel();
    }
}
