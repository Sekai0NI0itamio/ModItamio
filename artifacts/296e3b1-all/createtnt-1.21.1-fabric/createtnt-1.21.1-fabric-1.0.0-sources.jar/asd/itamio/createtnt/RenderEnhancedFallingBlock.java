package asd.itamio.createtnt;

import net.minecraft.class_1540;
import net.minecraft.class_1921;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_901;
import org.joml.Matrix4f;

/**
 * Renderer for {@link EntityEnhancedFallingBlock}.
 *
 * <p>The vanilla {@link class_901} only draws blocks with a baked
 * model — fluids (water/lava) have no model, so scattered fluid blobs would
 * be invisible. This renderer delegates solid blocks to the parent and draws
 * a semi-transparent colored cube for fluids so the player can see flying
 * water/lava blobs.</p>
 */
public class RenderEnhancedFallingBlock extends class_901 {

    public RenderEnhancedFallingBlock(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public void method_3965(class_1540 entity, float entityYaw, float partialTicks,
                       class_4587 poseStack, class_4597 buffer, int packedLight) {
        class_2680 state = entity.method_6962();
        if (state != null && state.method_26204() instanceof class_2404) {
            renderFluidCube(entity, state, poseStack, buffer);
            return;
        }
        super.method_3965(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    /**
     * Draws a semi-transparent colored cube for fluid falling blocks.
     * Water = light blue, lava = bright orange, with a subtle wobble so the
     * blob reads as liquid rather than a static cube.
     */
    private void renderFluidCube(class_1540 entity, class_2680 state,
                                 class_4587 poseStack, class_4597 buffer) {
        float r, g, b, alpha;
        if (state.method_26227().method_15767(class_3486.field_15518)) {
            r = 0.95F; g = 0.40F; b = 0.05F; alpha = 0.85F;
        } else {
            // Water (and any other fluid defaults to water-blue).
            r = 0.20F; g = 0.40F; b = 0.85F; alpha = 0.70F;
        }

        poseStack.method_22903();
        // Center the cube on the entity.
        poseStack.method_46416(-0.49F, 0.0F, -0.49F);
        // Subtle wobble so the blob looks alive.
        float wobble = (float) Math.sin(entity.field_6012 * 0.3D) * 0.05F;
        poseStack.method_46416(0.49F, 0.49F, 0.49F);
        poseStack.method_22905(1.0F + wobble, 1.0F - wobble, 1.0F + wobble);
        poseStack.method_46416(-0.49F, -0.49F, -0.49F);

        class_4588 vc = buffer.getBuffer(class_1921.method_49042());
        Matrix4f mat = poseStack.method_23760().method_23761();

        float x0 = 0.01F, y0 = 0.01F, z0 = 0.01F;
        float x1 = 0.97F, y1 = 0.97F, z1 = 0.97F;

        // -Z face
        quad(vc, mat, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, r, g, b, alpha);
        // +Z face
        quad(vc, mat, x0, y0, z1, x0, y1, z1, x1, y1, z1, x1, y0, z1, r, g, b, alpha);
        // -X face
        quad(vc, mat, x0, y0, z0, x0, y1, z0, x0, y1, z1, x0, y0, z1, r, g, b, alpha);
        // +X face
        quad(vc, mat, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, r, g, b, alpha);
        // -Y face
        quad(vc, mat, x0, y0, z0, x0, y0, z1, x1, y0, z1, x1, y0, z0, r, g, b, alpha);
        // +Y face
        quad(vc, mat, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, r, g, b, alpha);

        poseStack.method_22909();
    }

    private static void quad(class_4588 vc, Matrix4f mat,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2,
                             float x3, float y3, float z3,
                             float x4, float y4, float z4,
                             float r, float g, float b, float a) {
        vc.method_22918(mat, x1, y1, z1).method_22915(r, g, b, a);
        vc.method_22918(mat, x2, y2, z2).method_22915(r, g, b, a);
        vc.method_22918(mat, x3, y3, z3).method_22915(r, g, b, a);
        vc.method_22918(mat, x4, y4, z4).method_22915(r, g, b, a);
    }
}
