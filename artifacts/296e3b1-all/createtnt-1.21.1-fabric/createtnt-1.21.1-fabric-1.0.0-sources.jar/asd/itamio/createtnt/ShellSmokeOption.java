package asd.itamio.createtnt;

import net.minecraft.class_2394;
import net.minecraft.class_2396;

/** Particle options for the big explosion smoke puff: lifetime + size scale.
 *  {@code trail} marks the rocket flight trail puffs, which hang almost in
 *  place instead of drifting apart like the explosion cloud puffs. */
public record ShellSmokeOption(int lifetime, float scale, boolean trail) implements class_2394 {
    @Override
    public class_2396<?> method_10295() {
        return BetterTNTs.SHELL_EXPLOSION_SMOKE;
    }
}
