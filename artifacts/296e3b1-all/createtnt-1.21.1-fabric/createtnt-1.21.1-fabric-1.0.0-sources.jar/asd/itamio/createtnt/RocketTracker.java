package asd.itamio.createtnt;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1541;
import net.minecraft.class_1671;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_9284;
import net.minecraft.class_9334;

/** Tracks crossbow/dispenser firework rockets for acceleration, drilling and shell blasts. */
public final class RocketTracker {
    private static final double ACCEL = 0.025D;
    private static final double MAX_SPEED = 3.0D;
    private static final int MAX_TRACK_AGE = 1200;
    private static final int MAX_TRACKED = 200;
    private static final double RANGE_SQR = 1.0E8D;
    private static final int MAX_DRILL = 3;        // break up to 3 blocks, then detonate
    private static final double DRILL_STEP = 0.2D; // march step along the flight vector
    // Trail puffs are small, so ShellExplosionSmokeParticle keeps only 30% of the
    // requested lifetime: 240 ticks resolve to ~72 ticks (3.6 s) on screen.
    private static final int TRAIL_LIFETIME = 240;
    private static final float TRAIL_SCALE = 1.5F;
    private static final Map<UUID, Tracked> TRACKED = new LinkedHashMap<>();

    private static final class Tracked {
        final class_3218 level; final class_1297 rocket; final int stars;
        double x, y, z, mx, my, mz; int age; int drilled;
        Tracked(class_3218 level, class_1297 rocket) {
            this.level = level; this.rocket = rocket;
            this.stars = RocketTracker.starsFrom(((class_1671) rocket).method_7495());
            snapshot();
        }
        void snapshot() {
            x = rocket.method_23317(); y = rocket.method_23318(); z = rocket.method_23321();
            class_243 motion = rocket.method_18798(); mx = motion.field_1352; my = motion.field_1351; mz = motion.field_1350;
        }
    }

    private RocketTracker() { }
    public static void track(class_3218 level, class_1671 rocket) {
        if (TRACKED.size() < MAX_TRACKED) TRACKED.putIfAbsent(rocket.method_5667(), new Tracked(level, rocket));
    }
    public static void untrack(UUID id) { TRACKED.remove(id); }

    /** Number of explosion stars in the firework; 0 = no blast. */
    public static int starsFrom(class_1799 stack) {
        class_9284 fw = stack.method_57824(class_9334.field_49616);
        return fw != null ? fw.comp_2392().size() : 0;
    }

    /** Gunpowder flight level of the firework, clamped to 0..7. */
    public static int flightFrom(class_1799 stack) {
        class_9284 fw = stack.method_57824(class_9334.field_49616);
        int v = fw != null ? fw.comp_2391() : 0;
        return Math.max(0, Math.min(7, v));
    }

    public static void tickAll() {
        if (TRACKED.isEmpty()) return;
        boolean enabled = ModConfig.rocketShellExplosions;
        Iterator<Map.Entry<UUID, Tracked>> it = TRACKED.entrySet().iterator();
        while (it.hasNext()) {
            Tracked tr = it.next().getValue();
            if (tr.rocket.method_31481()) {
                if (enabled) detonateShell(tr.level, (class_1671) tr.rocket);
                it.remove(); continue;
            }
            if (tr.age > MAX_TRACK_AGE) { it.remove(); continue; }
            tr.snapshot(); tr.age++;
            if (!enabled) continue;
            if (tr.stars > 0 && tr.drilled < MAX_DRILL) {
                class_243 motion = tr.rocket.method_18798();
                double speed = motion.method_1033();
                if (speed > 1.0E-4D) {
                    double reach = Math.min(speed, MAX_SPEED) + 0.5D;
                    for (double d = DRILL_STEP; d <= reach && tr.drilled < MAX_DRILL; d += DRILL_STEP) {
                        class_2338 pos = class_2338.method_49637(
                            tr.x + motion.field_1352 / speed * d,
                            tr.y + motion.field_1351 / speed * d,
                            tr.z + motion.field_1350 / speed * d);
                        class_2680 state = tr.level.method_8320(pos);
                        if (state.method_26215() || state.method_26220(tr.level, pos).method_1110()) continue;
                        if (state.method_26214(tr.level, pos) < 0.0F) break;   // unbreakable wall
                        tr.level.method_30093(pos, false, tr.rocket, class_2248.field_31025);             // no drops, with break effects
                        tr.drilled++;
                    }
                    if (tr.drilled >= MAX_DRILL) {
                        detonateShell(tr.level, (class_1671) tr.rocket);
                        it.remove();
                        continue;
                    }
                }
            }
            class_243 motion = tr.rocket.method_18798(); double speed = motion.method_1033();
            if (speed > 1.0E-4D && speed < MAX_SPEED) {
                class_243 dir = motion.method_1029();
                tr.rocket.method_18799(motion.method_1019(dir.method_1021(Math.min(ACCEL, MAX_SPEED - speed))));
            }
            sendTrail(tr.level, tr.x, tr.y, tr.z);
        }
    }

    /**
     * Sends this tick's trail puffs to every player who could see them. The
     * plain sendParticles call stops at 32 blocks, and clients drop unforced
     * particles past 32 blocks of the camera; the per-player overload with
     * force=true stretches that limit to the 512-block visible range and
     * marks the packet so clients render each puff at any distance, matching
     * the reach of the explosion visuals.
     */
    private static void sendTrail(class_3218 level, double x, double y, double z) {
        ShellSmokeOption trail = new ShellSmokeOption(TRAIL_LIFETIME, TRAIL_SCALE, true);
        for (class_3222 player : level.method_18456()) {
            level.method_14166(player, trail, true, x, y, z, 2, 0.1D, 0.1D, 0.1D, 0.0D);
        }
    }

    /**
     * Detonates a shell rocket. Stars scale block destruction (1 star = 1x ...
     * 7 stars = 4x); entity damage matches a TNT blast scaled by
     * {@link ModConfig#rocketExplosionDamageScale}. A rocket without stars only
     * flashes its directional plume.
     */
    public static void detonateShell(class_3218 level, class_1671 rocket) {
        double x = rocket.method_23317(), y = rocket.method_23318(), z = rocket.method_23321();
        class_243 motion = rocket.method_18798();
        double len = motion.method_1033();
        float axisX = 0.0F, axisY = 1.0F, axisZ = 0.0F;
        if (len >= 1.0E-4D) {
            axisX = (float) (-motion.field_1352 / len); axisY = (float) (-motion.field_1351 / len); axisZ = (float) (-motion.field_1350 / len);
        }
        int stars = starsFrom(rocket.method_7495());
        float directionalPower = 3.0F * (ModConfig.tntStrength / 4.0F);
        if (stars <= 0) {
            for (class_3222 player : level.method_18456()) {
                if (player.method_5649(x, y, z) >= RANGE_SQR) continue;
                ModNetwork.sendExplosion(player, new SpawnExplosionMessage(x, y, z,
                    directionalPower * 0.4F, true, 0.0F, 0.0F, 0.0F, axisX, axisY, axisZ));
            }
            rocket.method_31472();
            return;
        }
        int clampedStars = Math.min(7, stars);
        float starScale = 1.0F + (clampedStars - 1) * 0.5F;   // 1 star = 1x ... 7 stars = 4x
        float powerMult = 1.0F + level.method_8409().method_43057() * 2.0F;
        float blockPower = ModConfig.blockPower * powerMult * starScale;
        float entityPower = ModConfig.entityPower * powerMult * ModConfig.rocketExplosionDamageScale;
        float particlePower = ModConfig.tntStrength * (1.0F + (powerMult - 1.0F) * 0.25F);
        EnhancedExplosion boom = new EnhancedExplosion(level, rocket, x, y, z,
            blockPower, entityPower, false, true, particlePower);
        boom.setPlumeAxis(axisX, axisY, axisZ);
        boom.method_8348();
        boom.method_8350(true);
        float chainRadius = Math.max(blockPower, entityPower) * 2.0F + 4.0F;
        List<class_1541> chained = level.method_18467(class_1541.class,
            new class_238(x - chainRadius, y - chainRadius, z - chainRadius,
                x + chainRadius, y + chainRadius, z + chainRadius));
        for (class_1541 tnt : chained) tnt.method_6967(0);
        rocket.method_31472();
    }
}
