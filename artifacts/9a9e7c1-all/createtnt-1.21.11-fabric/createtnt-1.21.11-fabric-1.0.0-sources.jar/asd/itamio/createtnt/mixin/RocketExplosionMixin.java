package asd.itamio.createtnt.mixin;

import asd.itamio.createtnt.EnhancedExplosion;
import asd.itamio.createtnt.ModConfig;
import asd.itamio.createtnt.ModNetwork;
import asd.itamio.createtnt.RocketTracker;
import asd.itamio.createtnt.SpawnExplosionMessage;
import java.util.List;
import net.minecraft.class_1541;
import net.minecraft.class_1671;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2940;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Redirects enabled crossbow/dispenser fireworks into enhanced blasts. */
@Mixin(class_1671.class)
public class RocketExplosionMixin {
    @Shadow @Final
    private static class_2940<class_1799> DATA_ID_FIREWORKS_ITEM;

    @Inject(method = "explode", at = @At("HEAD"), cancellable = true)
    private void createtnt$redirectBlast(class_3218 level, CallbackInfo ci) {
        class_1671 self = (class_1671) (Object) this;
        if (level.method_8608() || !self.method_7477() || !ModConfig.rocketShellExplosions) return;
        double x = self.method_23317(), y = self.method_23318(), z = self.method_23321();
        class_243 motion = self.method_18798(); double len = motion.method_1033();
        float axisX = 0.0F, axisY = 1.0F, axisZ = 0.0F;
        if (len >= 1.0E-4D) {
            axisX = (float) (-motion.field_1352 / len); axisY = (float) (-motion.field_1351 / len); axisZ = (float) (-motion.field_1350 / len);
        }
        int stars = countStars(self);
        float directionalPower = 3.0F * (ModConfig.tntStrength / 4.0F);
        if (stars <= 0) {
            for (class_3222 player : level.method_18456()) {
                if (player.method_5649(x, y, z) < 1.0E8D) {
                    ModNetwork.sendExplosion(player, new SpawnExplosionMessage(x, y, z,
                        directionalPower * 0.4F, true, 0.0F, 0.0F, 0.0F, axisX, axisY, axisZ));
                }
            }
        } else {
            float powerMult = 1.0F + level.method_8409().method_43057() * 2.0F;
            float blockPower = ModConfig.blockPower * powerMult;
            float entityPower = ModConfig.entityPower * powerMult * stars;
            float particlePower = ModConfig.tntStrength * (1.0F + (powerMult - 1.0F) * 0.25F);
            EnhancedExplosion boom = new EnhancedExplosion(level, self, x, y, z,
                blockPower, entityPower, false, true, particlePower);
            boom.setPlumeAxis(axisX, axisY, axisZ);
            boom.detonate();
            boom.finalizeExplosion(true);
            float chainRadius = Math.max(blockPower, entityPower) * 2.0F + 4.0F;
            List<class_1541> chained = level.method_18467(class_1541.class,
                new class_238(x - chainRadius, y - chainRadius, z - chainRadius,
                    x + chainRadius, y + chainRadius, z + chainRadius));
            for (class_1541 tnt : chained) tnt.method_6967(0);
        }
        RocketTracker.untrack(self.method_5667());
        self.method_31472();
        ci.cancel();
    }

    private static int countStars(class_1671 self) {
        class_1799 stack = self.method_5841().method_12789(DATA_ID_FIREWORKS_ITEM);
        net.minecraft.class_9284 fw = stack.method_58694(net.minecraft.class_9334.field_49616);
        return fw != null ? fw.comp_2392().size() : 0;
    }
}
